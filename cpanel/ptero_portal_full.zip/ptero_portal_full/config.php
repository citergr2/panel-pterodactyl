<?php
declare(strict_types=1);

/*
 * Set these environment variables in your VPS web server / PHP-FPM config:
 * PTERO_PANEL_URL=https://panel.example.com
 * PTERO_PTLA_KEY=ptla_...
 * PTERO_ADMIN_PASSWORD=use-a-long-random-password
 *
 * Never commit API keys or this file with real credentials to a public repository.
 */
return [
    'panel_url' => getenv('PTERO_PANEL_URL') ?: 'https://panel.example.com',
    'ptla_key' => getenv('PTERO_PTLA_KEY') ?: '',
    'admin_password' => getenv('PTERO_ADMIN_PASSWORD') ?: '',
    'session_name' => 'ptero_portal_session',
    'page_size' => 50,
];
