import axios from 'axios'

const API_URL = String(process.env.SHOP_BOT_API_URL || '').trim()
const API_TOKEN = String(process.env.SHOP_BOT_API_TOKEN || '').trim()

let timer = null
let busy = false

async function checkPaymentProofs() {
    if (busy || !API_URL || !/^[a-f0-9]{64}$/i.test(API_TOKEN)) return

    const sock = global.sock

    // Jangan memulai pekerjaan saat socket belum siap.
    if (!sock?.user || sock !== global.sock) return

    busy = true

    try {
        const response = await axios.get(API_URL, {
            headers: { Authorization: `Bearer ${API_TOKEN}` },
            timeout: 15000
        })

        const job = response.data?.job
        if (!job) return

        if (
            !job.invoice ||
            !/^[a-f0-9]{32}\.(jpg|png|webp)$/i.test(
                String(job.proof_filename || '')
            ) &&
            !job.image_base64
        ) {
            console.error('[Payment watcher] Data bukti tidak valid')
            return
        }

        if (!job.image_base64 || !job.mime) {
            console.error('[Payment watcher] Data gambar tidak lengkap')
            return
        }

        const owners = [...new Set(
            (Array.isArray(global.owners) ? global.owners : [])
                .map(number => String(number).replace(/\D/g, ''))
                .filter(number => number.length >= 8)
        )]

        if (!owners.length) {
            console.error('[Payment watcher] Admin belum dikonfigurasi')
            return
        }

        const caption = [
            '🧾 *BUKTI PEMBAYARAN BARU*',
            '',
            `Invoice: ${job.invoice}`,
            `Produk: ${job.product || '-'}`,
            `Total: Rp${Number(job.total || 0).toLocaleString('id-ID')}`,
            `Status: ${job.status || 'pending'}`,
            '',
            '⚠️ Foto ini belum membuktikan dana masuk.',
            'Periksa mutasi DANA secara langsung sebelum menyetujui pembayaran.'
        ].join('\n')

        const image = Buffer.from(job.image_base64, 'base64')
        if (!image.length || image.length > 2 * 1024 * 1024) {
            console.error('[Payment watcher] Ukuran gambar tidak valid')
            return
        }

        let sent = false

        for (const number of owners) {
            try {
                // Socket bisa berganti ketika bot sedang reconnect.
                if (sock !== global.sock || !sock?.user) {
                    console.warn('[Payment watcher] Socket berubah; coba lagi pada pemeriksaan berikutnya.')
                    return
                }

                await sock.sendMessage(`${number}@s.whatsapp.net`, {
                    image,
                    mimetype: job.mime,
                    caption
                })
                sent = true
            } catch (error) {
                console.error(
                    '[Payment watcher] Gagal kirim ke salah satu admin:',
                    error.message
                )
            }
        }

        if (!sent) return

        await axios.post(API_URL, {
            action: 'ack',
            invoice: job.invoice
        }, {
            headers: {
                Authorization: `Bearer ${API_TOKEN}`,
                'Content-Type': 'application/json'
            },
            timeout: 15000
        })

        console.log('[Payment watcher] Notifikasi terkirim:', job.invoice)
    } catch (error) {
        console.error(
            '[Payment watcher] Pemeriksaan gagal:',
            error.response?.status || error.message
        )
    } finally {
        busy = false
    }
}

export function startPaymentProofWatcher() {
    if (timer) return

    console.log('[Payment watcher] Aktif; pemeriksaan setiap 15 detik')
    timer = setInterval(checkPaymentProofs, 15000)
    checkPaymentProofs()
}
