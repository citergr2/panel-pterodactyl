// ───────── tiktok ─────────
// Dipecah dari plugins/download/tiktok.js (dulu digabung dengan fitur lain dalam satu file)

import axios from 'axios'
import { wrapClassic, oneCommand } from '../../lib/engine/plugins.js'

const _tiktok = (() => {
async function searchTikTok(query) {
  const { data } = await axios.get(
    'https://tikwm.com/api/feed/search',
    {
      params: {
        keywords: query,
        count: 1
      },
      timeout: 20000
    }
  )

  if (!data || data.code !== 0 || !data.data?.videos?.length) {
    throw 'Hasil tidak ditemukan'
  }

  const v = data.data.videos[0]
  return `https://www.tiktok.com/@${v.author.unique_id}/video/${v.video_id}`
}

async function getTikTok(url) {
  const { data } = await axios.get(
    'https://tikwm.com/api/',
    {
      params: { url, hd: 1 },
      timeout: 20000
    }
  )

  if (!data || data.code !== 0) {
    throw 'Gagal mengambil data TikTok'
  }

  return data.data
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  await m.react('✨')

  const input = m.quoted ? m.quoted.text : text
  if (!input) {
    return m.reply(
      `Contoh:\n` +
      `${usedPrefix + command} https://vt.tiktok.com/xxxx\n` +
      `${usedPrefix + command} kaguya edit`
    )
  }

  try {
    let url = input

    if (!/^https?:\/\//i.test(input)) {
      url = await searchTikTok(input)
    }

    const res = await getTikTok(url)

    const title = (res.title || '-').replace(/\s+/g, ' ').trim()
    const uploader = res.author?.nickname || res.author?.unique_id || '-'
    const duration = formatDuration(res.duration)
    const views = formatNumber(res.play_count || res.play || res.views || 0)

    const caption = `
— DOWNLOADER TIKTOK —

❀ Judul : ${title.length > 80 ? title.slice(0, 80) + '...' : title}
❀ Uploader : ${uploader}
❀ Durasi : ${duration}
❀ Views : ${views}
`.trim()

    if (Array.isArray(res.images) && res.images.length > 0) {
      await conn.sendMessage(
        m.chat,
        {
          album: res.images.map((img, i) => ({
            image: { url: img },
            caption: i === 0 ? caption : ''
          }))
        },
        { quoted: m }
      )

      if (res.music) {
        await conn.sendMessage(
          m.chat,
          {
            audio: { url: res.music },
            mimetype: 'audio/mpeg'
          },
          { quoted: m }
        )
      }

      await m.react('✅')
      return
    }

    if (res.play) {
      await conn.sendMessage(
        m.chat,
        {
          video: { url: res.play },
          caption
        },
        { quoted: m }
      )
    }

    if (res.music) {
      await conn.sendMessage(
        m.chat,
        {
          audio: { url: res.music },
          mimetype: 'audio/mpeg'
        },
        { quoted: m }
      )
    }

    await m.react('✅')
  } catch (e) {
    await m.react('❌')
    throw String(e)
  }
}

handler.help = ['tt', 'tiktok']
handler.tags = ['download']
handler.command = ['tt', 'tiktok']
handler.limit = true
handler.register = false

const __plugin = wrapClassic(handler)
function formatNumber(num = 0) {
  return Number(num).toLocaleString()
}

function formatDuration(sec = 0) {
  const m = Math.floor(sec / 60).toString().padStart(2, '0')
  const s = Math.floor(sec % 60).toString().padStart(2, '0')
  return `${m}:${s}`
}

  return __plugin
})()

_tiktok.tags = ['download']   // kategori menu (dulu dari mergePlugins)

// satu command = nama file; command lain jadi sub-command
export default oneCommand(_tiktok, 'tiktok')
