// ───────── drivedl ─────────
// Dipecah dari plugins/download/storage.js (dulu digabung dengan fitur lain dalam satu file)

import { wrapClassic, oneCommand } from '../../lib/engine/plugins.js'
import path from 'path'
import fs, { writeFileSync } from 'fs'
import axios from 'axios'
import os, { tmpdir } from 'os'

const _googledrive = (() => {
/*
Fitur: Downloader Google Drive
Info: Mengunduh File dari link Drive
Type: Plugins
By: SkyWalker
[ `Sumber` ]
https://whatsapp.com/channel/0029Vb1NWzkCRs1ifTWBb13u

[ `Sumber Scrape` ]
https://whatsapp.com/channel/0029Vb2mOzL1Hsq0lIEHoR0N/346
*/

/*
const axios = require('axios')
const { writeFileSync } = require('fs')
const { tmpdir } = require('os')
const path = require('path')
*/

let handler = async (m, { args, usedPrefix, command, conn }) => {
  const url = args[0]
  if (!url) throw `Contoh: ${usedPrefix + command} https://drive.google.com/file/d/xxxxxxxxx/view`

  const fileId = await extractGDrive(url)
  if (!fileId) throw 'URL Google Drive tidak valid!'

  try {
    const apiKey = 'AIzaSyAA9ERw-9LZVEohRYtCWka_TQc6oXmvcVU'
    const metaUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?fields=name,size,mimeType&key=${apiKey}`
    const downloadUrl = `https://www.googleapis.com/drive/v3/files/${fileId}?alt=media&key=${apiKey}`

    const metadata = await axios.get(metaUrl)
    const { name, size, mimeType } = metadata.data

    m.reply(`Mendownload file...\n\n• Nama: ${name}\n• Ukuran: ${await formatSize(size)}\n• Tipe: ${mimeType}`)

    const res = await axios.get(downloadUrl, { responseType: 'arraybuffer' })

    if (res.status !== 200) {
      throw `Gagal mengunduh file: ${res.status} ${res.statusText}`
    }

    const buffer = Buffer.from(res.data, 'binary')
    const tmpPath = path.join(tmpdir(), name)
    writeFileSync(tmpPath, buffer)

    await conn.sendMessage(m.chat, {
      document: { url: tmpPath },
      fileName: name,
      mimetype: mimeType || 'application/octet-stream',
      caption: `File berhasil diunduh!\n\n• Nama: ${name}\n• Ukuran: ${await formatSize(size)}`
    }, { quoted: m })
  } catch (err) {
    console.error(err)
    throw typeof err === 'string' ? err : `Terjadi kesalahan: ${err.response?.status} ${err.response?.statusText}`
  }
}

handler.help = ['gdrive <url>']
handler.tags = ['download']
handler.command = ['drivedl']
const __plugin = wrapClassic(handler)
//module export= handler
async function extractGDrive(url) {
  const match = url.match(/\/d\/([^/]+)|open\?id=([^&]+)/)
  return match ? (match[1] || match[2]) : null
}

async function formatSize(bytes) {
  const sizes = ['B', 'KB', 'MB', 'GB']
  if (bytes === 0) return '0 B'
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i]
}

  return __plugin
})()

_googledrive.tags = ['download']   // kategori menu (dulu dari mergePlugins)

// satu command = nama file
export default oneCommand(_googledrive, 'drivedl')
