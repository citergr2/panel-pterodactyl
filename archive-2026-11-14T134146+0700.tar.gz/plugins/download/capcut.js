// ───────── capcut ─────────
// Dipecah dari plugins/download/video.js (dulu digabung dengan fitur lain dalam satu file)

import { wrapClassic, oneCommand } from '../../lib/engine/plugins.js'
import { capcut } from 'btch-downloader'
import fetch from 'node-fetch'

const _capcut = (() => {
/**
 * Fitur   : CapCut Downloader
 * Base    : capdownloader.com
 * Type    : Plugin ESM
 * Channel : https://whatsapp.com/channel/0029VbAYjQgKrWQulDTYcg2K
 * Creator : Hilman
 */

async function getCapcutVideo(url) {
  const res = await fetch(
    "https://capdownloader.com/wp-json/aio-dl/video-data/",
    {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "origin": "https://capdownloader.com",
        "referer": "https://capdownloader.com/",
        "user-agent": "Mozilla/5.0"
      },
      body: JSON.stringify({ url })
    }
  )

  if (!res.ok) throw "Server tidak merespon"

  const data = await res.json().catch(() => ({}))
  const video = data?.medias?.[0]?.url

  if (!video) throw "Media tidak tersedia"

  return video
}

let handler = async (m, { text, conn }) => {
  if (!text) throw "Masukkan link CapCut"
  if (!/capcut\.com/.test(text)) throw "Link tidak valid"

  await m.react("✨")

  try {
    const videoUrl = await getCapcutVideo(text)

    await conn.sendMessage(
      m.chat,
      { video: { url: videoUrl } },
      { quoted: m }
    )

    await m.react("✅")
  } catch (e) {
    console.log(e)
    await m.react("❌")
    m.reply("Gagal mengambil video")
  }
}

handler.help = ["capcut <link>"]
handler.tags = ['download']
handler.command = ['capcut']
handler.limit = true
handler.register = true

const __plugin = wrapClassic(handler)

  return __plugin
})()

_capcut.tags = ['download']   // kategori menu (dulu dari mergePlugins)

// satu command = nama file
export default oneCommand(_capcut, 'capcut')
