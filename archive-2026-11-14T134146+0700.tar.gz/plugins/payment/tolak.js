import axios from 'axios'

const handler = async (m, { text, reply }) => {
    const raw = String(text || '').trim()
    const match = raw.match(/^(XC-\d{8}-[A-F0-9]{8})\s+([\s\S]+)$/i)

    if (!match) {
        return reply(
            'Format: .tolak INVOICE alasan\n\n' +
            'Contoh:\n.tolak XC-20261103-AFA88925 Bukti pembayaran tidak sesuai'
        )
    }

    const apiUrl = String(process.env.SHOP_BOT_API_URL || '').trim()
    const apiToken = String(process.env.SHOP_BOT_API_TOKEN || '').trim()

    if (!apiUrl || !/^[a-f0-9]{64}$/i.test(apiToken)) {
        return reply('❌ Konfigurasi API pembayaran belum tersedia.')
    }

    const invoice = match[1].toUpperCase()
    const reason = match[2].trim()

    if (reason.length > 500) {
        return reply('❌ Alasan maksimal 500 karakter.')
    }

    try {
        const response = await axios.post(apiUrl, {
            action: 'reject',
            invoice,
            reason
        }, {
            headers: {
                Authorization: `Bearer ${apiToken}`,
                'Content-Type': 'application/json'
            },
            timeout: 15000
        })

        if (response.data?.ok) {
            return reply(
                `✅ *Bukti pembayaran ditolak*\n\n` +
                `Invoice: ${invoice}\n` +
                `Alasan: ${reason}\n\n` +
                `Pelanggan dapat melihat alasan ini dan mengunggah bukti pengganti.`
            )
        }

        return reply('❌ Penolakan tidak berhasil.')
    } catch (error) {
        const message = error.response?.data?.error
        return reply(`❌ Gagal menolak pembayaran: ${message || error.message}`)
    }
}

handler.command = ['tolak']
handler.owner = true
handler.help = ['tolak <invoice> <alasan>']
handler.tags = ['owner']

export default handler
