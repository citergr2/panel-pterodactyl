import axios from 'axios'
import * as C from '../../lib/panel/core.js'

const PLAN_BY_PRODUCT = {
    '1Gb': '1gb',
    '2Gb': '2gb',
    '3Gb': '3gb',
    '4Gb': '4gb',
    'UNLI': 'unli',
    'Paket Unli': 'unli'
}

async function api(action, invoice, extra = {}) {
    const url = String(process.env.SHOP_BOT_API_URL || '').trim()
    const token = String(process.env.SHOP_BOT_API_TOKEN || '').trim()

    if (!url || !/^[a-f0-9]{64}$/i.test(token)) {
        throw new Error('Konfigurasi API pembayaran belum tersedia.')
    }

    const response = await axios.post(url, {
        action,
        invoice,
        ...extra
    }, {
        headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        timeout: 20000
    })

    return response.data
}

const handler = async (m, { text, reply, sock }) => {
    const invoice = String(text || '').trim().toUpperCase()

    if (!/^XC-\d{8}-[A-F0-9]{8}$/.test(invoice)) {
        return reply(
            'Format:\n.terima INVOICE\n\nContoh:\n.terima XC-20261105-ABC12345'
        )
    }

    const c = C.cfg(1)

    if (!c.ready) {
        return reply(C.notReadyMsg(1))
    }

    const busyKey = invoice

    if (global.__shopTerimaBusy?.has(busyKey)) {
        return reply('Invoice ini sedang diproses.')
    }

    global.__shopTerimaBusy ||= new Set()
    global.__shopTerimaBusy.add(busyKey)

    let claim = null
    let user = null

    try {
        // Ambil invoice dan kunci proses
        claim = await api('claim', invoice)

        const order = claim.order
        const planKey = PLAN_BY_PRODUCT[order.product_id]
        const plan = planKey ? C.planOf(planKey) : null

        if (
            !plan ||
            ![plan.ram, plan.disk, plan.cpu].every(
                value => Number.isFinite(value) && value >= 0
            )
        ) {
            await api('release', invoice, {
                processing_token: claim.processing_token,
                reason: 'Konfigurasi paket tidak ditemukan'
            }).catch(() => null)

            return reply('Paket tidak ditemukan atau konfigurasi resource belum benar.')
        }

        if (!C.validUser(order.username)) {
            await api('release', invoice, {
                processing_token: claim.processing_token,
                reason: 'Username panel tidak valid'
            }).catch(() => null)

            return reply('Username pada invoice tidak valid.')
        }

        const phone = String(order.buyer_phone || '')

        if (!/^628[0-9]{7,11}$/.test(phone)) {
            await api('release', invoice, {
                processing_token: claim.processing_token,
                reason: 'Nomor WhatsApp tidak valid'
            }).catch(() => null)

            return reply('Nomor WhatsApp pembeli tidak valid.')
        }

        await reply(
            `⏳ Memproses pesanan\n\n` +
            `Invoice: ${invoice}\n` +
            `Pembeli: ${phone}\n` +
            `Paket: ${order.product_name}\n\n` +
            `Pastikan pembayaran sudah diperiksa secara manual.`
        )

        // Buat akun Pterodactyl
        user = await C.createUser(c, {
            username: order.username
        })

        if (!user.ok) {
            await api('release', invoice, {
                processing_token: claim.processing_token,
                reason: user.error || 'Gagal membuat user'
            })

            return reply(`❌ Gagal membuat akun: ${user.error || 'Unknown error'}`)
        }

        // Buat server Pterodactyl
        const created = await C.createServer(c, {
            name: order.username,
            userId: user.user.id,
            plan,
            description: `Order ${invoice}`
        })

        if (!created.ok) {
            const deleted = await C.deleteUser(c, user.user.id)

            if (deleted.ok) {
                await api('release', invoice, {
                    processing_token: claim.processing_token,
                    reason: created.error || 'Gagal membuat server'
                })

                return reply(
                    `❌ Server gagal dibuat.\n` +
                    `Akun sementara berhasil dibersihkan.\n\n` +
                    `Alasan: ${created.error || 'Unknown error'}`
                )
            }

            return reply(
                `⚠️ Server gagal dibuat dan akun sementara belum berhasil dibersihkan.\n` +
                `Invoice tetap terkunci untuk pemeriksaan manual.\n` +
                `User ID: ${user.user.id}`
            )
        }

        // Tandai invoice selesai setelah server berhasil dibuat
        await api('complete', invoice, {
            processing_token: claim.processing_token,
            panel_user_id: user.user.id,
            panel_server_id: created.server.id
        })

        const store = C.store()

        const message = [
            '☾ PESANAN PANEL KAMU SUDAH SIAP',
            '',
            `Invoice: ${invoice}`,
            `Username: ${order.username}`,
            `Password: ${user.password}`,
            `Login: ${c.domain}`,
            `Paket: ${C.planTitle(planKey)}`,
            `RAM: ${C.mbLabel(plan.ram)}`,
            `Disk: ${C.mbLabel(plan.disk)}`,
            `CPU: ${C.cpuLabel(plan.cpu)}`,
            '',
            `Terima kasih telah membeli di ${store.name}`,
            store.contact ? `Kontak: ${store.contact}` : '',
            store.web ? `Website: ${store.web}` : ''
        ].filter(Boolean).join('\n')

        // Kirim detail login ke WhatsApp pembeli
        try {
            await sock.sendMessage(C.toPN(phone), {
                text: message
            })

            return reply(
                `✅ PESANAN BERHASIL\n\n` +
                `Invoice: ${invoice}\n` +
                `Username: ${order.username}\n` +
                `Server ID: ${created.server.id}\n` +
                `Detail login berhasil dikirim ke pembeli.`
            )
        } catch (sendError) {
            // Jangan tampilkan password di grup.
            // Kirim cadangan hanya ke chat pribadi admin.
            try {
                await sock.sendMessage(m.sender, {
                    text: `Pengiriman ke pembeli gagal. Berikut detail untuk diteruskan secara pribadi:\n\n${message}`
                })
            } catch {}

            return reply(
                `⚠️ Server berhasil dibuat, tetapi pesan ke pembeli gagal.\n` +
                `Detail login dikirim ke chat pribadi admin jika memungkinkan.\n` +
                `Invoice: ${invoice}`
            )
        }

    } catch (error) {
        const message = error.response?.data?.error || error.message

        if (!claim) {
            return reply(`❌ Gagal mengambil invoice: ${message}`)
        }

        return reply(
            `⚠️ Proses terhenti: ${message}\n\n` +
            `Invoice tetap terkunci untuk mencegah server ganda.\n` +
            `Periksa panel Pterodactyl sebelum melakukan pemulihan manual.\n` +
            `Invoice: ${invoice}`
        )
    } finally {
        global.__shopTerimaBusy.delete(busyKey)
    }
}

handler.command = ['terima']
handler.owner = true
handler.help = ['terima <invoice>']
handler.tags = ['owner']

export default handler
