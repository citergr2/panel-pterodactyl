/**
 * YannRzy Panel Pterodactyl — beli & kelola panel Pterodactyl (API reseller)
 *
 * Satu command: .yannpanel <fitur> ...
 *   produk                         daftar produk
 *   order <produkId> <user> <pass> <email>   buat order baru
 *   bayar <invoice>                cek status pembayaran
 *   detail <invoice>               detail order (data panel kalau sudah dibayar)
 *   orders                         daftar semua order
 *   garansi                        link garansi
 *   cekserver <serverId> [panelUrl]   cek server
 *   renew <serverId> [panelUrl]    buat tagihan perpanjangan
 *   cekrenew <trxId>               cek pembayaran perpanjangan
 *   pesan <idproduk>               format order siap salin untuk produk itu
 *
 * Tanpa fitur (.yannpanel) menampilkan menu tombol; tombol yang gagal terkirim jatuh ke teks biasa.
 *
 * Pengaturan di config.js -> global.yannpanel = { url, apiKey }
 * (apiKey juga bisa lewat env YANNPANEL_API_KEY).
 *
 * AKSES: PUBLIK untuk semua orang (ini fitur jualan). Yang tetap khusus owner: `cekserver`.
 * Pembeli biasa hanya bisa melihat order miliknya sendiri (detail/orders), tidak bisa melihat order orang lain.
 */

import { recordZan, recordAction, hasPurchased, panelDB } from '../../lib/panel/log.js'

const cfg = () => {
    const c = global.yannpanel || global.zanpanel || {}
    return {
        url: String(c.url || process.env.YANNPANEL_URL || process.env.ZANPANEL_URL || 'https://zanspiwptero.shoppanel.my.id').replace(/\/+$/, ''),
        apiKey: String(c.apiKey || process.env.YANNPANEL_API_KEY || process.env.ZANPANEL_API_KEY || ''),
        panelUrl: String(c.panelUrl || ''),
        timeoutMs: Number(c.timeoutMs) || 30_000
    }
}

// ───────── HTTP ─────────
async function api(method, path, { body, query } = {}) {
    const { url, apiKey, timeoutMs } = cfg()
    if (!apiKey || /YOUR_API_KEY/i.test(apiKey)) {
        throw 'API key belum diisi. Isi `global.yannpanel.apiKey` di config.js (format sk_live_...).'
    }

    const qs = query ? '?' + new URLSearchParams(query).toString() : ''
    let res
    try {
        res = await fetch(`${url}/api/v1/${path}${qs}`, {
            method,
            headers: {
                Authorization: `Bearer ${apiKey}`,
                Accept: 'application/json',
                ...(body ? { 'Content-Type': 'application/json' } : {})
            },
            body: body ? JSON.stringify(body) : undefined,
            signal: AbortSignal.timeout(timeoutMs)
        })
    } catch (e) {
        throw e?.name === 'TimeoutError' ? 'Server panel terlalu lama merespon, coba lagi nanti.' : `Gagal menghubungi server panel: ${e?.cause?.code || e?.message || e}`
    }

    const raw = await res.text()
    let json
    try { json = JSON.parse(raw) } catch { json = { raw } }

    if (!res.ok) {
        const msg = json?.message || json?.error || json?.raw?.slice(0, 200) || `HTTP ${res.status}`
        throw `Ditolak server (${res.status}): ${typeof msg === 'string' ? msg : JSON.stringify(msg)}`
    }
    if (json?.success === false || json?.status === false) {
        throw `Gagal: ${json.message || json.error || 'permintaan tidak berhasil'}`
    }
    return json
}

// ───────── format ─────────
const rp = (n) => (Number.isFinite(Number(n)) ? 'Rp' + Number(n).toLocaleString('id-ID') : String(n ?? '-'))
const pick = (o, ...keys) => { for (const k of keys) if (o?.[k] !== undefined && o[k] !== null && o[k] !== '') return o[k]; return undefined }
const unwrap = (j) => j?.data ?? j?.result ?? j
const asList = (j) => {
    const d = unwrap(j)
    if (Array.isArray(d)) return d
    for (const k of ['products', 'orders', 'items', 'list', 'data']) if (Array.isArray(d?.[k])) return d[k]
    return []
}

// field `product` dari server bisa berupa OBJEK ({ name, type, memory, ... }); jangan sampai tercetak "[object Object]"
const prodName = (v) => {
    if (v && typeof v === 'object') return String(v.name ?? v.productId ?? v.id ?? v.title ?? '') || undefined
    return v === undefined || v === null || v === '' ? undefined : String(v)
}
const productOfOrder = (x) => prodName(pick(x, 'product', 'productName', 'productId'))
const numOf = (jid) => String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '')
const ownsOrder = (invoice, sender) => {
    const z = panelDB().zan[String(invoice)]
    return !!z?.by && !!numOf(sender) && numOf(z.by) === numOf(sender)
}

const HIDE = new Set(['password', 'apikey', 'api_key', 'token', 'secret'])
// cetak objek apa adanya (tanpa asumsi nama field) supaya semua data dari server tetap terlihat
function dump(obj, indent = '') {
    if (obj === null || obj === undefined) return ''
    if (typeof obj !== 'object') return `${indent}${obj}`
    const lines = []
    for (const [k, v] of Object.entries(obj)) {
        if (v === null || v === undefined || v === '') continue
        if (typeof v === 'object') {
            lines.push(`${indent}${k}:`)
            lines.push(dump(v, indent + '  '))
        } else {
            lines.push(`${indent}${k}: ${HIDE.has(k.toLowerCase()) && indent ? '••••' : v}`)
        }
    }
    return lines.join('\n')
}

function payInfo(d) {
    const lines = []
    const invoice = pick(d, 'invoice', 'invoiceId', 'orderId', 'trxId', 'id')
    const total = pick(d, 'total', 'totalPayment', 'amount', 'price', 'grossAmount')
    const status = pick(d, 'status', 'paymentStatus')
    const expire = pick(d, 'expiredAt', 'expiresAt', 'expired', 'expiry')
    const payUrl = pick(d, 'paymentUrl', 'payment_url', 'checkoutUrl', 'checkout_url', 'url', 'link')
    if (invoice) lines.push(`🧾 Invoice : *${invoice}*`)
    if (total !== undefined) lines.push(`💰 Total   : *${rp(total)}*`)
    if (status) lines.push(`📌 Status  : ${status}`)
    if (expire) lines.push(`⏳ Expired : ${expire}`)
    if (payUrl) lines.push(`🔗 Bayar   : ${payUrl}`)
    return { text: lines.join('\n'), invoice, qr: pick(d, 'qrUrl', 'qr_url', 'qrImage', 'qrisUrl', 'qris_url', 'qrCode', 'qr') }
}

const HELP = (p, bought = false, isOwner = false) =>
    `*YANNRZY PANEL PTERODACTYL*\n\n` +
    `${p}yannpanel produk\n` +
    `${p}yannpanel order <idproduk> <username> <password> <email>\n` +
    `${p}yannpanel bayar <invoice>\n` +
    `${p}yannpanel detail <invoice>\n` +
    `${p}yannpanel orders\n` +
    (bought ? `${p}yannpanel garansi\n` : '') +
    (isOwner ? `${p}yannpanel cekserver <serverId> [panelUrl]\n` : '') +
    `${p}yannpanel renew <serverId> [panelUrl]\n` +
    `${p}yannpanel cekrenew <trxId>\n\n` +
    `_Contoh: ${p}yannpanel order public-1GB budi Rahasia123! budi@gmail.com_`

// ───────── catatan lokal (database/store.json -> panel.zan) ─────────
// Semua order/perpanjangan yang lewat bot disimpan lokal (tanpa password), jadi riwayat tidak bergantung pada server panel.
const statusOf = (d) => pick(d, 'status', 'paymentStatus')
const totalOf = (d) => pick(d, 'total', 'totalPayment', 'amount', 'price', 'grossAmount')
const keep = (type, d, extra = {}) => {
    try {
        const info = payInfo(d)
        const invoice = extra.invoice || info.invoice
        if (!invoice) return
        // pemilik order = yang pertama membuatnya; cek/lihat oleh orang lain tidak boleh mengambil alih
        if (panelDB().zan[String(invoice)]?.by) { delete extra.by; delete extra.chat }
        recordZan({ type, invoice, total: totalOf(d), status: statusOf(d), raw: d, ...extra })
    } catch (e) { console.error('[ YANNPANEL ] gagal catat:', e?.message || e) }
}

// ───────── tombol ─────────
const quick = (text, id) => ({ type: 'reply', text, id })
const copy = (text, code) => ({ type: 'copy', text, code: String(code) })
const listBtn = (text, rows, title = 'Menu') => ({ type: 'list', text, sections: [{ title, rows }] })
// daftar pilihan banyak: dipecah per 10 baris supaya semua item tetap muncul (bukan hanya 10 pertama)
const listSections = (text, groups) => ({
    type: 'list', text,
    sections: groups.flatMap(({ title, rows }) => {
        const out = []
        for (let i = 0; i < rows.length; i += 10) {
            const n = Math.ceil(rows.length / 10)
            out.push({ title: (n > 1 ? `${title} (${Math.floor(i / 10) + 1}/${n})` : title).slice(0, 24), rows: rows.slice(i, i + 10) })
        }
        return out
    })
})

// produk -> { id, name, price, stock, desc, group }; group = id tanpa segmen ukuran di belakang ("public-v2-7GB" -> "public-v2")
const productOf = (x) => {
    const id = String(pick(x, 'productId', 'id', 'slug', 'code') ?? '')
    const dash = id.lastIndexOf('-')
    return {
        id, name: String(pick(x, 'name', 'title') || id),
        price: pick(x, 'price', 'harga'), stock: pick(x, 'stock', 'stok'), desc: pick(x, 'description', 'desc', 'deskripsi'),
        group: (dash > 0 ? id.slice(0, dash) : 'lainnya').toLowerCase()
    }
}
const byGroupPrice = (a, b) => a.group.localeCompare(b.group) || (Number(a.price) || 0) - (Number(b.price) || 0) || a.name.localeCompare(b.name, undefined, { numeric: true })
const groupTitle = (g) => g.toUpperCase()
const productLine = (x, i) => `${i + 1}. *${x.name}*\n   ID    : ${x.id}\n   Harga : ${rp(x.price)}${x.stock !== undefined ? `\n   Stok  : ${x.stock}` : ''}${x.desc ? `\n   Info  : ${String(x.desc).slice(0, 120)}` : ''}`

// kirim pesan bertombol; kalau gagal (atau perangkat tidak mendukung), kirim teks + daftar perintahnya
async function sendBtn(sock, m, jid, body, buttons, image) {
    const base = { text: body, footer: global.namebot || 'YannRzy Panel Pterodactyl', buttons }
    const attempts = image ? [{ ...base, image }, base] : [base]
    for (const o of attempts) {
        try { return await sock.sendButtons(jid || m.chat, o, { quoted: m }) } catch {}
    }
    let extra = ''
    try {
        const { buttonsToText } = await import('../../lib/platform/wa.js')
        extra = buttonsToText(buttons)
    } catch {}
    return sock.sendMessage(jid || m.chat, { text: extra ? `${body}\n\n${extra}` : body }, { quoted: m })
}

// ───────── handler ─────────
let handler = async (m, { sock, text, command, prefix, reply, jid, isOwner }) => {
    const p = prefix || '.'
    const args = String(text || '').trim().split(/\s+/).filter(Boolean)
    // dipanggil `.yannpanel produk ...` -> ctx.command = 'produk'; dipanggil `.yannpanel` saja -> bantuan
    const sub = command === 'yannpanel' ? '' : command

    // garansi hanya untuk yang sudah pernah membeli
    const bought = hasPurchased(m.sender, jid)

    if (!sub) {
        const z = `${p}yannpanel`
        return sendBtn(sock, m, jid,
            `*YANNRZY PANEL PTERODACTYL*\n\nPilih menu di bawah. Menu yang butuh data (order, bayar, detail, dst.) akan menampilkan format pengisiannya.`,
            [
                listBtn('📋 Pilih Menu', [
                    { title: '🛍 Daftar Produk', description: 'Lihat produk dan harga', id: `${z} produk` },
                    { title: '🧾 Order Baru', description: 'Format buat order panel', id: `${z} order` },
                    { title: '💳 Cek Pembayaran', description: 'Status invoice order', id: `${z} bayar` },
                    { title: '📄 Detail Order', description: 'Data panel setelah dibayar', id: `${z} detail` },
                    { title: '📚 Semua Order', description: 'Riwayat order', id: `${z} orders` },
                    ...(bought ? [{ title: '🛡 Link Garansi', description: 'Link klaim garansi', id: `${z} garansi` }] : []),
                    ...(isOwner ? [{ title: '🖥 Cek Server', description: 'Status server panel', id: `${z} cekserver` }] : []),
                    { title: '🔁 Perpanjang', description: 'Buat tagihan renew', id: `${z} renew` },
                    { title: '🔎 Cek Perpanjangan', description: 'Status bayar renew', id: `${z} cekrenew` }
                ], 'YannRzy Panel'),
                quick('🛍 Produk', `${z} produk`),
                quick('📚 Order Saya', `${z} orders`)
            ])
    }

    try {
        switch (sub) {
            case 'produk': {
                const items = asList(await api('GET', 'products')).map(productOf).filter(x => x.id).sort(byGroupPrice)
                if (!items.length) return reply('Belum ada produk.')

                const groups = [...new Set(items.map(x => x.group))]
                const wanted = args.join(' ').toLowerCase()
                const tg = sock.platform === 'telegram'

                // Telegram: tombol dibatasi, jadi produk dikelompokkan per kategori (tap kategori -> daftar produknya)
                if (tg) {
                    const send = (body, rows) => sock.sendMessage(jid || m.chat, { text: body, _markup: { inline_keyboard: rows } }, { quoted: m })
                    const mine = wanted && groups.includes(wanted) ? items.filter(x => x.group === wanted) : null

                    if (!mine) {
                        const rows = groups.map(g => {
                            const gi = items.filter(x => x.group === g)
                            return [{ text: `${groupTitle(g)} (${gi.length})`, callback_data: `${p}yannpanel produk ${g}` }]
                        })
                        rows.push([{ text: '📚 Order Saya', callback_data: `${p}yannpanel orders` }])
                        return send(`*PRODUK PANEL*\n\n${items.length} produk dalam ${groups.length} kategori. Pilih kategori:`, rows)
                    }

                    const rows = mine.map(x => [{ text: `${x.name} - ${rp(x.price)}`.slice(0, 56), callback_data: `${p}yannpanel pesan ${x.id}` }])
                    rows.push([{ text: '◀ Semua Kategori', callback_data: `${p}yannpanel produk` }, { text: '📚 Order Saya', callback_data: `${p}yannpanel orders` }])
                    return send(`*PRODUK ${groupTitle(wanted)}* (${mine.length})\n\n${mine.map(productLine).join('\n\n')}\n\nTekan produk di bawah untuk mendapat format order.`, rows)
                }

                // WhatsApp: semua produk muncul di daftar pilihan, dipecah per kategori & per 10 baris
                const shown = wanted && groups.includes(wanted) ? items.filter(x => x.group === wanted) : items
                const body = `*PRODUK PANEL*\n\n${shown.map(productLine).join('\n\n')}\n\nPilih produk di tombol untuk mendapat format order.`
                const choices = [...new Set(shown.map(x => x.group))].map(g => ({
                    title: groupTitle(g),
                    rows: shown.filter(x => x.group === g).map(x => ({ title: x.name.slice(0, 24), description: x.price !== undefined ? rp(x.price) : '', id: `${p}yannpanel pesan ${x.id}` }))
                }))
                return sendBtn(sock, m, jid, body, [listSections('🛒 Pilih Produk', choices), quick('📚 Order Saya', `${p}yannpanel orders`)])
            }

            case 'pesan': {
                const id = args.join(' ')
                if (!id) return reply(`Format: ${p}yannpanel pesan <idproduk>\nLihat id produk: ${p}yannpanel produk`)
                const tpl = `${p}yannpanel order ${id} username password email@gmail.com`
                return sendBtn(sock, m, jid,
                    `*ORDER ${id}*\n\nTekan *Salin Format*, lalu ganti:\n• username → nama akun panel\n• password → minimal 8 karakter\n• email → email pembeli\n\n${tpl}`,
                    [copy('📋 Salin Format', tpl), quick('🛍 Produk Lain', `${p}yannpanel produk`)])
            }

            case 'order': {
                // id produk boleh memuat spasi (mis. "python-Python 6GB"): 3 kata terakhir = username, password, email
                const [email, password, username] = args.slice(-3).reverse()
                const productId = args.slice(0, -3).join(' ')
                if (!productId || !username || !password || !email) {
                    return reply(`Format:\n${p}yannpanel order <idproduk> <username> <password> <email>\n\nContoh:\n${p}yannpanel order public-1GB budi Rahasia123! budi@gmail.com\n\nLihat id produk: ${p}yannpanel produk`)
                }
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return reply('Format email tidak valid.')
                if (password.length < 8) return reply('Password minimal 8 karakter.')

                // anti-spam: maksimal 3 order belum dibayar per pengguna dalam 1 jam (owner bebas)
                if (!isOwner) {
                    const pending = Object.values(panelDB().zan).filter(z => z.type === 'order' && !z.paid && numOf(z.by) === numOf(m.sender) && Date.now() - z.createdAt < 3600_000)
                    if (pending.length >= 3) return reply('Kamu masih punya 3 order yang belum dibayar. Bayar atau tunggu 1 jam sebelum membuat order baru.')
                }
                const res = await api('POST', 'create-order', { body: { productId, username, password, email } })
                const d = unwrap(res)
                const info = payInfo(d)
                keep('order', d, { invoice: info.invoice, productId, username, email, by: m.sender, chat: m.chat, status: statusOf(d) || 'pending' })
                const body = `✅ *ORDER DIBUAT*\n\n${info.text || dump(d)}\n\nProduk   : ${productId}\nUsername : ${username}\nEmail    : ${email}\n\nCek bayar: ${p}yannpanel bayar ${info.invoice || '<invoice>'}\n_Sebaiknya hapus pesan yang berisi password tadi._`

                const buttons = info.invoice
                    ? [quick('💳 Cek Pembayaran', `${p}yannpanel bayar ${info.invoice}`), copy('📋 Salin Invoice', info.invoice), quick('📄 Detail Order', `${p}yannpanel detail ${info.invoice}`)]
                    : [quick('📚 Order Saya', `${p}yannpanel orders`)]
                const qr = String(info.qr || '')
                const image = /^https?:\/\//.test(qr) ? qr : /^data:image\/\w+;base64,/.test(qr) ? Buffer.from(qr.split(',')[1], 'base64') : undefined
                return sendBtn(sock, m, jid, body, buttons, image)
            }

            case 'bayar': {
                if (!args[0]) return reply(`Format: ${p}yannpanel bayar <invoice>\nContoh: ${p}yannpanel bayar INV-171829-PUBLIC-1GB`)
                const d = unwrap(await api('GET', `check-payment/${encodeURIComponent(args[0])}`))
                keep('order', d, { invoice: args[0] })
                return sendBtn(sock, m, jid, `*STATUS PEMBAYARAN*\n\n${payInfo(d).text || dump(d)}`,
                    [quick('🔄 Cek Lagi', `${p}yannpanel bayar ${args[0]}`), quick('📄 Detail Order', `${p}yannpanel detail ${args[0]}`)])
            }

            case 'detail': {
                if (!args[0]) return reply(`Format: ${p}yannpanel detail <invoice>`)
                if (!isOwner && !ownsOrder(args[0], m.sender)) return reply('Order tidak ditemukan atau bukan milik kamu. Cek daftar order kamu dengan ' + p + 'yannpanel orders')
                const d = unwrap(await api('GET', `order-detail/${encodeURIComponent(args[0])}`))
                keep('order', d, {
                    invoice: args[0], productId: productOfOrder(d), username: pick(d, 'username', 'user'),
                    email: pick(d, 'email'), serverId: pick(d, 'serverId', 'server_id')
                })
                return reply(`*DETAIL ORDER*\n\n${dump(d)}`)
            }

            case 'orders': {
                const all = asList(await api('GET', 'orders'))
                // API mengembalikan SEMUA order toko; pembeli biasa hanya boleh melihat order miliknya sendiri
                const list = isOwner ? all : all.filter(x => ownsOrder(pick(x, 'invoice', 'invoiceId', 'orderId', 'id'), m.sender))
                if (!list.length) return reply(isOwner ? 'Belum ada order.' : 'Kamu belum punya order. Mulai dengan ' + p + 'yannpanel produk')
                for (const x of list) {
                    keep('order', x, {
                        invoice: pick(x, 'invoice', 'invoiceId', 'orderId', 'id'), productId: productOfOrder(x),
                        username: pick(x, 'username', 'user'), email: pick(x, 'email')
                    })
                }
                const rows = list.slice(0, 30).map((x, i) => {
                    const inv = pick(x, 'invoice', 'invoiceId', 'orderId', 'id')
                    const st = pick(x, 'status', 'paymentStatus')
                    const pr = productOfOrder(x)
                    const tot = pick(x, 'total', 'amount', 'price')
                    return `${i + 1}. ${inv}${pr ? ` — ${pr}` : ''}${tot !== undefined ? ` — ${rp(tot)}` : ''}${st ? ` [${st}]` : ''}`
                })
                // WhatsApp: 30 order terbaru semuanya masuk daftar pilihan; Telegram: 10 terbaru (tombol inline)
                const choices = list.slice(0, sock.platform === 'telegram' ? 10 : 30).map(x => {
                    const inv = pick(x, 'invoice', 'invoiceId', 'orderId', 'id')
                    return { title: String(inv).slice(0, 24), description: [productOfOrder(x), pick(x, 'status', 'paymentStatus')].filter(Boolean).join(' · '), id: `${p}yannpanel detail ${inv}` }
                })
                return sendBtn(sock, m, jid, `*DAFTAR ORDER* (${list.length})\n\n${rows.join('\n')}${list.length > 30 ? `\n\n_menampilkan 30 terbaru dari ${list.length}_` : ''}`,
                    [listSections('📄 Lihat Detail', [{ title: 'Order terbaru', rows: choices }]), quick('🛍 Produk', `${p}yannpanel produk`)])
            }

            case 'garansi': {
                if (!bought) return reply('Link garansi hanya tersedia untuk yang sudah pernah membeli.')
                const d = unwrap(await api('GET', 'warranty-link'))
                const link = typeof d === 'string' ? d : pick(d, 'link', 'url', 'warrantyLink')
                return reply(`*LINK GARANSI*\n\n${link || dump(d)}`)
            }

            case 'cekserver': {
                if (!isOwner) return reply(global.mess?.owner || 'Fitur ini khusus owner.')
                const [serverId, panelArg] = args
                const panelUrl = panelArg || cfg().panelUrl
                if (!serverId) return reply(`Format: ${p}yannpanel cekserver <serverId> [panelUrl]\nContoh: ${p}yannpanel cekserver 123 https://panel.example.com`)
                if (!panelUrl) return reply('Sertakan panelUrl, atau isi `global.yannpanel.panelUrl` di config.js.')
                const d = unwrap(await api('GET', `check-server/${encodeURIComponent(serverId)}`, { query: { panelUrl } }))
                recordAction({ action: 'zan_cekserver', server: 0, target: serverId, by: String(m.sender || '').split('@')[0], byRole: 'bot', ok: true, data: { panelUrl, result: d } })
                return reply(`*INFO SERVER ${serverId}*\n\n${dump(d)}`)
            }

            case 'renew': {
                const [serverId, panelArg] = args
                const panelUrl = panelArg || cfg().panelUrl
                if (!/^\d+$/.test(serverId || '')) return reply(`Format: ${p}yannpanel renew <serverId> [panelUrl]\nContoh: ${p}yannpanel renew 123 https://panel.example.com`)
                if (!panelUrl) return reply('Sertakan panelUrl, atau isi `global.yannpanel.panelUrl` di config.js.')
                const d = unwrap(await api('POST', 'create-renewal', { body: { serverId: Number(serverId), panelUrl } }))
                const info = payInfo(d)
                keep('renew', d, { invoice: info.invoice, serverId, panelUrl, by: m.sender, chat: m.chat, status: statusOf(d) || 'pending' })
                const body = `🔁 *PERPANJANGAN DIBUAT*\n\n${info.text || dump(d)}\n\nServer: ${serverId}\nCek bayar: ${p}yannpanel cekrenew ${info.invoice || '<trxId>'}`
                const qr = String(info.qr || '')
                return sendBtn(sock, m, jid, body,
                    info.invoice ? [quick('🔄 Cek Perpanjangan', `${p}yannpanel cekrenew ${info.invoice}`), copy('📋 Salin ID', info.invoice)] : [quick('📚 Order Saya', `${p}yannpanel orders`)],
                    /^https?:\/\//.test(qr) ? qr : undefined)
            }

            case 'cekrenew': {
                if (!args[0]) return reply(`Format: ${p}yannpanel cekrenew <trxId>\nContoh: ${p}yannpanel cekrenew TRX-RENEW-123456`)
                const d = unwrap(await api('GET', `check-renewal-payment/${encodeURIComponent(args[0])}`))
                keep('renew', d, { invoice: args[0] })
                return sendBtn(sock, m, jid, `*STATUS PERPANJANGAN*\n\n${payInfo(d).text || dump(d)}`, [quick('🔄 Cek Lagi', `${p}yannpanel cekrenew ${args[0]}`)])
            }

            default:
                return reply(HELP(p, bought, isOwner))
        }
    } catch (e) {
        return reply(typeof e === 'string' ? `⚠️ ${e}` : `⚠️ Terjadi error: ${e?.message || e}`)
    }
}

handler.command = ['yannpanel']
handler.subs = ['pesan', 'produk', 'order', 'bayar', 'detail', 'orders', 'garansi', 'cekserver', 'renew', 'cekrenew']
handler.help = ['yannpanel']
handler.tags = ['beli-pterodactyl']
// handler.owner dihapus: fitur ini publik untuk pembeli (cekserver tetap dicek owner di dalam handler)

export default handler
