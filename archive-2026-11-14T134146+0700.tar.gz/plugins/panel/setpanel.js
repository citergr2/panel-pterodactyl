// .setpanel <domain> <plta> [pltc] [nodeId]  -> simpan panel Pterodactyl PRIBADIMU (chat pribadi)
// .setpanel            -> lihat status      .setpanel hapus -> hapus panel pribadimu
// Dipakai fitur kelola panel (listusr, listsrv, delusr, delsrv, suspend, addsrv, dst). Bukan untuk jualan panel.
import * as C from '../../lib/panel/core.js'
import { getOwn, setOwn, delOwn, mask, secretGuard, wipeMessage } from '../../lib/core/usercreds.js'
import { checkDomain, cfgFromOwn } from '../../lib/panel/userpanel.js'

let handler = async (m, { sock, text, prefix, command, reply, sender, isOwner }) => {
    const args = String(text || '').trim().split(/\s+/).filter(Boolean)
    const cmd = `${prefix}${command}`

    if (!args.length) {
        const own = getOwn(sender, 'panel')
        const bawaan = isOwner && C.cfg(1).ready ? 'panel bawaan bot (config.js)' : 'belum ada'
        return reply(
            `🖥 *PANEL PRIBADI*\n\n` +
            (own
                ? `• Domain : ${own.domain}\n• PLTA   : \`${mask(own.plta)}\`\n• PLTC   : \`${own.pltc ? mask(own.pltc) : '-'}\`\n• Node   : ${own.node || '-'}\n\n`
                : `Belum diset. Yang dipakai: ${bawaan}\n\n`) +
            `Simpan: *${cmd} <domain> <plta> [pltc] [nodeId]*\n` +
            `Contoh: ${cmd} https://panel.domainmu.com ptla_xxx ptlc_xxx\nHapus : *${cmd} hapus*\n\n` +
            `_PLTA = Application API key (Admin > Application API). PLTC (opsional) = Client API key, untuk status on/off server. Lakukan di chat pribadi._`
        )
    }

    if (/^(hapus|delete|del|reset)$/i.test(args[0])) {
        return reply(delOwn(sender, 'panel') ? '🗑️ Panel pribadimu dihapus.' : 'Kamu belum menyimpan panel pribadi.')
    }

    if (!(await secretGuard(sock, m, reply, prefix))) return
    const [domainRaw, plta, pltc, node] = args
    if (!plta) return reply(`Format: *${cmd} <domain> <plta> [pltc] [nodeId]*`)
    if (node && !/^\d+$/.test(node)) return reply('nodeId harus angka.')

    const chk = await checkDomain(domainRaw)
    if (!chk.ok) return reply(`❌ ${chk.error}`)

    // uji key sebelum disimpan
    const c = cfgFromOwn({ domain: chk.domain, plta, pltc: pltc || '', node })
    const r = await C.call(c, 'app', 'GET', '/api/application/users', null, { per_page: 1 })
    await wipeMessage(sock, m)
    if (!r.ok) return reply(`❌ Gagal terhubung ke panel: ${C.why(r)}\nPeriksa domain dan PLTA (harus Application API key dengan izin baca/tulis).`)

    const st = setOwn(sender, 'panel', { domain: chk.domain, plta, pltc: pltc || '', node: node || '' })
    return reply(`✅ *Panel pribadi ${st === 'diganti' ? 'diperbarui' : 'tersimpan'}* (${chk.domain}, ${r.data?.meta?.pagination?.count ?? '?'} user).\n\nCoba: ${prefix}listusr\n_Pesan berisi key sudah coba dihapus; kalau masih ada, hapus manual._`)
}

handler.command = ['setpanel']
handler.help = ['setpanel <domain> <plta> [pltc]']
handler.tags = ['panel']

export default handler
