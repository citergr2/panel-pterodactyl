// Laporan semua data panel yang tersimpan (database/store.json -> panel). Khusus owner bot.
//   .panelriwayat [hal]    riwayat penjualan panel & akun admin (terbaru dulu, sukses + gagal)
//   .panelrekap            rekap: penjualan, omset (jika paket diberi harga), per paket, per penjual
//   .panelserver [hal]     server yang pernah dibuat + status akhirnya (aktif / suspend / dihapus)
//   .panellog [hal]        log kelola panel (hapus, suspend, addsrv) dan perubahan peran penjual
//   .panelzan [hal]        order & perpanjangan YannRzy Panel Pterodactyl yang pernah dicek lewat bot
// Password tidak pernah disimpan. Harga per paket opsional: config.js -> global.panel.plans.<paket>.price
import * as UI from '../../lib/panel/ui.js'
import { panelDB, panelSummary } from '../../lib/panel/log.js'

const { bold: B } = UI
const PER = 10
const WIB = 7 * 36e5
const stamp = (t) => (t ? new Date(t + WIB).toISOString().slice(0, 16).replace('T', ' ') : '-')
const rp = (n) => 'Rp' + (Number(n) || 0).toLocaleString('id-ID')
const num = (jid) => String(jid || '').split('@')[0].split(':')[0] || '-'
const ROLE = { reseller: 'Reseller', admin: 'Admin', pt: 'PT', owner: 'Owner Panel', bot: 'Owner Bot' }

function page(list, text) {
    const total = Math.max(1, Math.ceil(list.length / PER))
    const p = Math.min(total, Math.max(1, parseInt(String(text || '').trim().split(/\s+/)[0]) || 1))
    return { p, total, rows: list.slice((p - 1) * PER, p * PER) }
}

const foot = (cmd, prefix, p, total, count) =>
    [UI.LINE, `Halaman ${p}/${total} • total ${count}`, ...(p < total ? [`Berikutnya: ${prefix}${cmd} ${p + 1}`] : [])]

function riwayat(d, text, prefix) {
    const list = Object.values(d.sales).sort((a, b) => b.createdAt - a.createdAt)
    if (!list.length) return 'Belum ada penjualan panel tercatat.'
    const { p, total, rows } = page(list, text)
    const lines = rows.map(s => [
        `${s.status === 'done' ? '✅' : '❌'} ${B(s.id)} • ${s.title}${s.server > 1 ? ` (server ${s.server})` : ''}`,
        `   Pembeli : +${s.buyerNum || num(s.buyer)}  |  Penjual : +${num(s.seller)} (${ROLE[s.sellerRole] || '-'})`,
        `   Akun    : ${s.username || '-'}${s.userId !== undefined ? ` (ID ${s.userId})` : ''}${s.serverId !== undefined ? `  Server ID ${s.serverId}` : ''}`,
        ...(s.price ? [`   Harga   : ${rp(s.price)}`] : []),
        ...(s.error ? [`   Gagal   : ${s.stage || '-'} — ${s.error}`] : []),
        `   Waktu   : ${stamp(s.createdAt)} WIB`
    ].join('\n'))
    return [`☾ ${B('RIWAYAT PENJUALAN PANEL')}`, UI.LINE, lines.join('\n\n'), ...foot('panelriwayat', prefix, p, total, list.length)].join('\n')
}

function rekap(d) {
    const s = panelSummary()
    const today = new Date(Date.now() + WIB).toISOString().slice(0, 10)
    const month = today.slice(0, 7)
    const done = Object.values(d.sales).filter(x => x.status === 'done')
    const at = (x) => new Date((x.doneAt || x.createdAt) + WIB).toISOString().slice(0, 10)
    const dToday = done.filter(x => at(x) === today)
    const dMonth = done.filter(x => at(x).startsWith(month))
    const sum = (a) => a.reduce((t, x) => t + (Number(x.price) || 0), 0)
    const plans = Object.entries(s.byPlan).sort((a, b) => b[1] - a[1]).map(([k, v]) => `   ${k}: ${v}x`)
    const sellers = Object.entries(d.sellers).sort((a, b) => (b[1].sales + b[1].admins) - (a[1].sales + a[1].admins)).slice(0, 5)
        .map(([n, v], i) => `   ${i + 1}. +${n} (${ROLE[v.role] || '-'}) — ${v.sales} paket, ${v.admins} admin${v.failed ? `, ${v.failed} gagal` : ''}`)
    const buyers = Object.entries(d.customers).sort((a, b) => b[1].orders - a[1].orders).slice(0, 5)
        .map(([n, v], i) => `   ${i + 1}. +${n} — ${v.orders} paket${v.admins ? `, ${v.admins} admin` : ''}`)
    return [
        `☾ ${B('REKAP PANEL')}`, UI.LINE,
        `Hari ini  : ${dToday.length} pesanan • ${rp(sum(dToday))}`,
        `Bulan ini : ${dMonth.length} pesanan • ${rp(sum(dMonth))}`,
        `Semua     : ${s.done} berhasil (${s.plans} paket, ${s.admins} admin) • ${rp(s.omset)}`,
        `Gagal     : ${s.failed}`, '',
        `Server    : ${s.servers} dibuat • ${s.active} aktif • ${s.suspended} suspend • ${s.deleted} dihapus`,
        `Penjual   : ${s.sellers} orang  |  Pembeli : ${s.customers} orang`,
        `Pterodactyl: ${s.zan} order/renew • ${s.zanPaid} lunas`, '',
        B('Per paket'), ...(plans.length ? plans : ['   —']), '',
        B('Penjual teratas'), ...(sellers.length ? sellers : ['   —']), '',
        B('Pembeli teratas'), ...(buyers.length ? buyers : ['   —']), UI.LINE,
        '_Omset hanya terhitung kalau paket diberi harga di config (plans.<paket>.price)._'
    ].join('\n')
}

function servers(d, text, prefix) {
    const list = Object.values(d.servers).sort((a, b) => b.createdAt - a.createdAt)
    if (!list.length) return 'Belum ada server panel tercatat.'
    const { p, total, rows } = page(list, text)
    const icon = { active: '🟢', suspended: '⏸️', deleted: '🗑️' }
    const lines = rows.map(s => [
        `${icon[s.status] || '•'} ${B(s.name || s.username || '-')} • server ${s.server} ID ${s.id}`,
        `   Status  : ${s.status}${s.userDeleted ? ' (akun user dihapus)' : ''}${s.manual ? ' • dibuat manual' : ''}`,
        ...(s.key ? [`   Paket   : ${String(s.key).toUpperCase()}`] : []),
        ...(s.buyer ? [`   Pembeli : +${num(s.buyer)}`] : []),
        `   Dibuat  : ${stamp(s.createdAt)} WIB`
    ].join('\n'))
    return [`☾ ${B('SERVER PANEL')}`, UI.LINE, lines.join('\n\n'), ...foot('panelserver', prefix, p, total, list.length)].join('\n')
}

function logs(d, text, prefix) {
    const merged = [
        ...d.actions.map(a => ({ at: a.at, line: `${a.ok ? '✅' : '❌'} ${a.action} ${a.target ?? ''} • server ${a.server}${a.error ? ` — ${a.error}` : ''}` })),
        ...d.roleLog.map(r => ({ at: r.at, line: `${r.ok ? '👤' : '➖'} ${r.action === 'add' ? 'tambah' : 'cabut'} ${ROLE[r.role] || r.role} +${r.number}${r.ok ? '' : ' (tidak berubah)'} • oleh +${r.by || '-'}` }))
    ].sort((a, b) => b.at - a.at)
    if (!merged.length) return 'Belum ada log kelola panel.'
    const { p, total, rows } = page(merged, text)
    return [`☾ ${B('LOG KELOLA PANEL')}`, UI.LINE, rows.map(x => `${stamp(x.at)}  ${x.line}`).join('\n'), ...foot('panellog', prefix, p, total, merged.length)].join('\n')
}

function zan(d, text, prefix) {
    const list = Object.values(d.zan).sort((a, b) => (b.updatedAt || b.createdAt) - (a.updatedAt || a.createdAt))
    if (!list.length) return 'Belum ada order Panel Pterodactyl tercatat. Order yang dibuat/dicek lewat .yannpanel otomatis disimpan.'
    const { p, total, rows } = page(list, text)
    const lines = rows.map(z => [
        `${z.paid ? '✅' : '⏳'} ${B(z.id)} • ${z.type === 'renew' ? 'perpanjang' : 'order'}`,
        `   ${z.productId ? `Produk : ${z.productId}` : `Server : ${z.serverId ?? '-'}`}${z.username ? `  |  Akun : ${z.username}` : ''}`,
        `   Total  : ${z.total !== undefined ? rp(z.total) : '-'}  |  Status : ${z.status || '-'}`,
        `   Update : ${stamp(z.updatedAt || z.createdAt)} WIB`
    ].join('\n'))
    return [`☾ ${B('ORDER PANEL PTERODACTYL')}`, UI.LINE, lines.join('\n\n'), ...foot('panelzan', prefix, p, total, list.length)].join('\n')
}

let handler = async (m, { text, prefix, command, reply }) => {
    const d = panelDB()
    if (command === 'panelrekap') return reply(rekap(d))
    if (command === 'panelserver') return reply(servers(d, text, prefix))
    if (command === 'panellog') return reply(logs(d, text, prefix))
    if (command === 'panelzan') return reply(zan(d, text, prefix))
    return reply(riwayat(d, text, prefix))
}

handler.command = ['panelriwayat']
handler.subs = ['panelrekap', 'panelserver', 'panellog', 'panelzan']
handler.help = ['panelriwayat', 'panelrekap', 'panelserver', 'panellog', 'panelzan']
handler.tags = ['panel']
handler.owner = true

export default handler
