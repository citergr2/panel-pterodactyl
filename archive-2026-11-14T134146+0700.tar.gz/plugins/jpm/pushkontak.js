import { getMeta } from '../../lib/platform/wa.js'
import { jpmCfg, jpmJobs, jpmLoop, getMedia, mediaContent, memberJids } from '../../lib/group/sosial.js'

// Kirim pesan pribadi ke semua member grup tempat perintah dipakai (akun bot dilewati).
let handler = async (m, { sock, jid, text, reply, example }) => {
    const media = await getMedia(m)
    if (!text && !media) return example('pesan yang ingin di-push ke member  (atau reply foto/video + caption)')

    const jobs = jpmJobs()
    if (jobs.pushRunning) return reply('❌ Push kontak sedang berjalan. Ketik *stoppush* untuk menghentikan.')

    const members = await memberJids(sock, await getMeta(sock, jid, true))
    if (!members.length) return reply('❌ Tidak ada member yang bisa dituju di grup ini.')

    const delay = jpmCfg().delayPushKontak
    jobs.pushRunning = true
    await reply(`*▢ PUSH KONTAK*\n• Target : ${members.length} member\n• Delay : ${delay}ms\n\nHentikan dengan *stoppush*`)

    let result
    try {
        result = await jpmLoop(members, delay, to =>
            sock.sendMessage(to, media ? mediaContent(media, text) : { text }), () => !jobs.pushRunning)
    } finally {
        jobs.pushRunning = false
    }

    return reply(`*▢ PUSH KONTAK SELESAI*\n• Berhasil : ${result.ok} member\n• Gagal : ${result.fail} member`)
}

handler.command = ['pushkontak']
handler.tags = ['jpm']
handler.owner = true
handler.group = true

export default handler
