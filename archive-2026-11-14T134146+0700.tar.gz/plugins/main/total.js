/**
 * Kaguya Multi Device — WhatsApp & Tele Bot
 *
 * Library      : whiskeysockets baileys
 * Type         : Plugins | ESM Modules
 * Creator      : YannRzy Tech
 * Recode       : (Your Name)
 *
 * Official Channels:
 * • https://whatsapp.com/channel/0029VaoMGuLA89MbfGh62V16
 *
 * Copyright © YannRzy Tech 2026
 * All Rights Reserved.
 */

import { expandPlugins } from '../../lib/engine/plugins.js'

// Semua command sebuah plugin: command utama + subs (sama seperti menu.js)
const menuCmds = h => [...new Set(
    [
        ...(Array.isArray(h.command) ? h.command : [h.command]),
        ...(Array.isArray(h.subs) ? h.subs : [])
    ]
        .map(String)
        .filter(c => c && !c.includes('_'))
)]

function countCommands() {
    let command = 0

    for (const h of expandPlugins()) {
        if (!h || !h.command || h.command instanceof RegExp || h.disabled) continue

        command += menuCmds(h).length
    }

    return command
}

let handler = async (m, { reply }) => {
    const total = countCommands().toLocaleString('id-ID')
    const botName = global.namebot ? String(global.namebot) : 'BOT'

    return reply(`📊 *TOTAL COMMAND ${botName.toUpperCase()}*\n\nTotal command : *${total}*`)
}

handler.command = ['t']
handler.help = ['t']
handler.tags = ['main']

export default handler
