/**
 * Kaguya Multi Device — WhatsApp & Tele Bot
 *
 * Library      : whiskeysockets/baileys
 * Type         : Plugins | ESM Modules
 * Creator      : YannRzy Tech
 * Recode       : Your Name
 *
 * Official Channels:
 * https://whatsapp.com/channel/0029VaoMGuLA89MbfGh62V16
 *
 * Copyright © YannRzy Tech 2026
 * All Rights Reserved.
 */

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { spawn } from 'child_process'
import {
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    proto
} from '@whiskeysockets/baileys'
import { runtime, footerText, docStore } from '../../lib/core/system.js'
import { primaryPrefix, expandPlugins, rpgStore, toPN, telegramHidden, isTelegramHidden } from '../../lib/engine/plugins.js'
import { operatorOf } from '../tools/cekoperator.js'
import { isIosId, chatIsIos } from '../../lib/platform/wa.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const rootDir = path.join(__dirname, '../../')

// ───────── pengaturan ─────────

const getMenuImage = () => global.thumb?.menu || global.thumb?.utama
const getAudioUrl = () => global.audioMenu || ''
const getCreator = () => global.creator || global.ownername || ''

// Tipe baru (isi di config.js):
//   global.videoMenu = 'https://.../menu.mp4'   -> tipe video (diputar sebagai GIF)
//   global.docMenu   = 'https://.../menu.pdf'   -> tipe doc (opsional, kalau kosong dibuat dokumen dummy)
const getMenuVideo = () => global.thumb?.videoMenu || 'https://cdn.zass.in/8yaSI5BefZ.mp4'
const getMenuDoc = () => global.thumb?.docMenu || ''

const CHANNEL_URL = 'https://whatsapp.com/channel/0029VaoMGuLA89MbfGh62V16'

const CATEGORIES = [
    'premium',
    'gacha-nokos',
    'beli-pterodactyl',
    'store',
    'main',
    'rich',
    'panel',
    'channel',
    'github',
    'vercel',
    'vps',
    'group',
    'jpm',
    'sticker',
    'canvas',
    'download',
    'stalker',
    'fun',
    'tools',
    'search',
    'asisten',
    'audio',
    'clan',
    'convert',
    'economy',
    'game',
    'tebak',
    'uno',
    'genshin',
    'koboy',
    'catur',
    'gaple',
    'crypto',
    'relationship',
    'rpg',
    'user',
    'owner'
]

// ikon tiap kategori (dipakai di daftar, tombol, dan judul)
const CAT_ICON = {
    premium: '💎',
    'gacha-nokos': '🎰',
    'beli-pterodactyl': '🦕',
    store: '🛒',
    main: '🏠',
    rich: '💰',
    panel: '🖥️',
    channel: '📢',
    github: '🐙',
    vercel: '▲',
    vps: '☁️',
    group: '👥',
    jpm: '📨',
    sticker: '🎨',
    canvas: '🖼️',
    download: '📥',
    stalker: '🕵️',
    fun: '🎉',
    tools: '🛠️',
    search: '🔎',
    asisten: '🤖',
    audio: '🎧',
    clan: '🛡️',
    convert: '🔄',
    economy: '🪙',
    game: '🎮',
    tebak: '🧠',
    uno: '🃏',
    genshin: '🌸',
    koboy: '🤠',
    catur: '♟️',
    gaple: '🀄',
    crypto: '🪙',
    relationship: '💞',
    rpg: '⚔️',
    user: '👤',
    owner: '👑'
}

const iconOf = cat => CAT_ICON[cat] || '📁'

const IOS_PER_PAGE = 2
const ANDROID_ROWS_PER_SECTION = 10
const BODY_MAX = 1000
const CAPTION_MAX = 3000
const TEXT_MAX = 60000

// carousel
const CAROUSEL_PER_PAGE = 10   // kartu per pesan (batas aman WhatsApp)
const CAROUSEL_CMD_PER_CARD = 20

const isIosMessage = m =>
    isIosId(m.key?.id) || (!m.isGroup && chatIsIos(m.chat))

// ───────── helper ─────────

const readPkg = file => {
    try {
        return JSON.parse(fs.readFileSync(file, 'utf8'))
    } catch {
        return null
    }
}

const chunk = (arr, n) => {
    const out = []
    for (let i = 0; i < arr.length; i += n) {
        out.push(arr.slice(i, i + n))
    }
    return out
}

// Semua command sebuah plugin: command utama + subs, tanpa memperhatikan `hide`.
const menuCmds = h => [...new Set(
    [
        ...(Array.isArray(h.command) ? h.command : [h.command]),
        ...(Array.isArray(h.subs) ? h.subs : [])
    ]
        .map(String)
        .filter(c => c && !c.includes('_'))
)]

// ───────── hitung total command ─────────

function countCommands() {
    let command = 0

    for (const h of expandPlugins()) {
        if (!h || !h.command || h.command instanceof RegExp || h.disabled) continue

        command += menuCmds(h).length
    }

    return command
}

function countFeatures() {
    let n = 0

    for (const h of expandPlugins()) {
        if (!h || !h.command || h.command instanceof RegExp || h.disabled) continue

        if (menuCmds(h).length) n++
    }

    return n
}

const RANKS = [
    [100, 'Master'],
    [75, 'Diamond'],
    [50, 'Platinum'],
    [25, 'Gold'],
    [10, 'Silver'],
    [0, 'Bronze']
]

const rankOf = level => {
    const lv = Math.max(0, Number(level) || 0)
    return RANKS.find(([min]) => lv >= min)[1]
}

// ───────── info script ─────────

function getScriptInfo() {
    const botPkg = readPkg(path.join(rootDir, 'package.json'))
    const libPkg = readPkg(
        path.join(rootDir, 'node_modules/@whiskeysockets/baileys/package.json')
    )

    let dbFiles = 0

    try {
        dbFiles = fs.readdirSync(path.join(rootDir, 'database'))
            .filter(f => f.endsWith('.json')).length
    } catch {}

    return {
        botVersion: botPkg?.version || '1.0.0',
        isEsm: botPkg?.type === 'module',
        type: `plugins manager (${botPkg?.type === 'module' ? 'ESM' : 'CJS'})`,
        total: countCommands(),
        features: countFeatures(),
        library: libPkg?.name || 'Baileys',
        version: libPkg?.version || '-',
        runtime: `NodeJS ${process.version}`,
        database: `LocalJSON (${dbFiles} file)`
    }
}

// ───────── kategori plugin ─────────

const getCategories = h => {
    const tags = Array.isArray(h.tags)
        ? h.tags
        : h.tags
            ? [h.tags]
            : []

    return [...new Set(
        tags
            .map(tag => String(tag).trim().toLowerCase())
            .filter(Boolean)
    )]
}

// ───────── RPG helper ─────────

const fmtNum = n => Math.floor(Number(n) || 0).toLocaleString('id-ID')

// ───────── helper tampilan menu ─────────

function longRuntime(sec) {
    sec = Math.max(0, Math.floor(Number(sec) || 0))

    const d = Math.floor(sec / 86400)
    const h = Math.floor((sec % 86400) / 3600)
    const m = Math.floor((sec % 3600) / 60)
    const s = sec % 60

    // Ringkas: "2d 4h 10m"
    const parts = [[d, 'd'], [h, 'h'], [m, 'm'], [s, 's']]
        .filter(([n]) => n > 0)
        .slice(0, 3)
        .map(([n, u]) => `${n}${u}`)

    return parts.length ? parts.join(' ') : '0s'
}

const greet = () => {
    const h = new Date(
        new Date().toLocaleString('en-US', { timeZone: 'Asia/Jakarta' })
    ).getHours()

    if (h < 4) return 'Selamat malam'
    if (h < 11) return 'Selamat pagi'
    if (h < 15) return 'Selamat siang'
    if (h < 18) return 'Selamat sore'
    return 'Selamat malam'
}

// Font small caps: "menu" -> "ᴍᴇɴᴜ" (tanda * dan simbol tidak berubah)
const SC = {
    a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ꜰ', g: 'ɢ', h: 'ʜ', i: 'ɪ',
    j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ',
    s: 'ꜱ', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
}

const font = t => String(t).toLowerCase().replace(/[a-z]/g, c => SC[c])

// ── kerangka kotak ──
//   ╭─「 ᴊᴜᴅᴜʟ 」
//   │ isi
//   ╰──────────────
const LINE = '╰──────────────'

const box = (title, rows) =>
    [`╭─「 ${font(title)} 」`, ...rows.map(r => `│ ${r}`), LINE].join('\n')

// Baris info: ◦ label : *nilai*
const kv = (k, v) => `◦ ${font(k)} : *${v}*`

// satu command di dalam kotak
const item = (p, c) => `⌬ ${p}${c}`

const pluginCount = () =>
    Object.values(global.plugins || {}).filter(Boolean).length

async function getRpgInfo(sock, m, { isOwner, isPremium }) {
    try {
        const pn = await toPN(sock, m.sender)
        const u = rpgStore().users[pn]

        if (!u) return null

        return {
            level: u.level ?? 1,
            role: u.role || 'Newbie',
            exp: fmtNum(u.exp),
            money: fmtNum(u.money),
            bank: fmtNum(u.bank),
            limit: isOwner || isPremium ? '∞' : fmtNum(u.limit),
            health: `${Math.floor(u.health ?? 100)}/${u.maxhealth ?? 100}`,
            registered: !!u.registered
        }
    } catch {
        return null
    }
}

// ───────── kumpulkan command ─────────

function collectCommands({ isOwner, isPremium, tgHidden = null }) {
    const groups = new Map()

    for (const h of expandPlugins()) {
        if (!h || !h.command || h.command instanceof RegExp || h.disabled) continue
        // Telegram: kategori yang disembunyikan (rich, rpg, relationship, user, fun, clan) tidak ikut menu
        if (tgHidden && isTelegramHidden(h, tgHidden)) continue

        const cmds = menuCmds(h)

        if (!cmds.length) continue

        const tags = getCategories(h)

        const categories = tags.length
            ? tags
            : [h.owner ? 'owner' : 'main']

        if ((h.owner || categories.includes('owner')) && !isOwner) continue
        if (h.premium && !isPremium) continue

        for (const cat of categories) {
            if (!groups.has(cat)) groups.set(cat, [])
            groups.get(cat).push([...new Set(cmds)])
        }
    }

    const order = [
        ...CATEGORIES.filter(k => k !== 'owner' && groups.has(k)),
        ...[...groups.keys()]
            .filter(k => !CATEGORIES.includes(k) && k !== 'owner')
            .sort(),
        ...(groups.has('owner') ? ['owner'] : [])
    ]

    return order.map(cat => ({
        cat,
        items: groups.get(cat).sort((a, b) =>
            a[0].localeCompare(b[0])
        ),
        total: groups.get(cat).reduce((n, cmds) => n + cmds.length, 0)
    }))
}

// ───────── convert audio ke opus ─────────

function toOpus(input) {
    return new Promise((resolve, reject) => {
        const ff = spawn('ffmpeg', [
            '-v', 'error',
            '-i', 'pipe:0',
            '-vn',
            '-c:a', 'libopus',
            '-b:a', '64k',
            '-ac', '1',
            '-ar', '48000',
            '-f', 'ogg',
            'pipe:1'
        ])

        const out = []
        let err = ''

        ff.stdout.on('data', d => out.push(d))
        ff.stderr.on('data', d => { err += d })
        ff.on('error', reject)

        ff.on('close', code => {
            const buf = Buffer.concat(out)

            if (code === 0 && buf.length) resolve(buf)
            else reject(new Error(err.trim() || `ffmpeg exit ${code}`))
        })

        ff.stdin.on('error', () => {})
        ff.stdin.end(input)
    })
}

// ───────── kirim VN ─────────

async function sendVN(sock, jid, url, quoted) {
    const res = await fetch(url)

    if (!res.ok) {
        throw new Error(`download audio gagal (${res.status})`)
    }

    const source = Buffer.from(await res.arrayBuffer())

    try {
        const opus = await toOpus(source)

        await sock.sendMessage(jid, {
            audio: opus,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true
        }, { quoted })
    } catch (e) {
        console.error('[MENU] Konversi VN gagal, kirim sebagai audio biasa:', e.message)

        await sock.sendMessage(jid, {
            audio: source,
            mimetype: 'audio/mpeg',
            ptt: false
        }, { quoted })
    }
}

// ───────── judul kategori ─────────

// "ai-image" -> "Ai Image" (nama kategori bertanda hubung dipecah per kata)
const catTitle = cat =>
    String(cat)
        .split('-')
        .map(w => w.charAt(0).toUpperCase() + w.slice(1))
        .join(' ')

// judul + ikon untuk tombol / baris daftar
const catLabel = cat => `${iconOf(cat)} ${catTitle(cat)}`

// ───────── tombol pintasan ─────────

// Tombol Sewa Bot -> menjalankan command .sewa (plugins/store/sewa.js).
const sewaButton = p => ({ type: 'reply', text: '🏷️ Sewa Bot', id: `${p}sewa` })

const quickButtons = p => [
    { type: 'reply', text: '👑 Owner', id: `${p}owner` },
    { type: 'reply', text: '🦕 Beli Panel Pterodactyl', id: `${p}yannpanel` },
    sewaButton(p)
]

function androidButtons(groups, p) {
    const rows = [
        {
            title: '📚 All Menu',
            description: 'Tampilkan seluruh fitur',
            id: `${p}menu all`
        },
        ...groups.map(g => ({
            title: catLabel(g.cat),
            description: `${g.total} command`,
            id: `${p}menu ${g.cat}`
        }))
    ]

    const sections = chunk(rows, ANDROID_ROWS_PER_SECTION).map((rs, i) => ({
        title: i === 0
            ? 'Pilih Kategori'
            : `Kategori (${i + 1})`,
        rows: rs
    }))

    return [{
        type: 'list',
        text: '📂 List Menu',
        sections
    }]
}

function iosMainButtons(groups, p, page) {
    const pages = Math.max(1, Math.ceil(groups.length / IOS_PER_PAGE))
    const now = Math.min(Math.max(page, 1), pages)

    const buttons = groups
        .slice((now - 1) * IOS_PER_PAGE, now * IOS_PER_PAGE)
        .map(g => ({
            type: 'reply',
            text: catLabel(g.cat),
            id: `${p}menu ${g.cat}`
        }))

    if (now > 1) {
        buttons.push({
            type: 'reply',
            text: '◀ Sebelumnya',
            id: `${p}menu hal${now - 1}`
        })
    }

    if (now < pages) {
        buttons.push({
            type: 'reply',
            text: 'Berikutnya ▶',
            id: `${p}menu hal${now + 1}`
        })
    }

    buttons.push(...quickButtons(p))

    return { buttons, page: now, pages }
}

function iosCategoryButtons(groups, cat, p) {
    const i = groups.findIndex(g => g.cat === cat)
    const prev = groups[(i - 1 + groups.length) % groups.length]
    const next = groups[(i + 1) % groups.length]
    const buttons = []

    if (groups.length > 1) {
        buttons.push({
            type: 'reply',
            text: `◀ ${catLabel(prev.cat)}`,
            id: `${p}menu ${prev.cat}`
        })
    }

    buttons.push({
        type: 'reply',
        text: '🏠 Menu Utama',
        id: `${p}menu`
    })

    if (groups.length > 2) {
        buttons.push({
            type: 'reply',
            text: `${catLabel(next.cat)} ▶`,
            id: `${p}menu ${next.cat}`
        })
    }

    buttons.push(...quickButtons(p))
    return buttons
}

// ───────── tipe pesan menu ─────────
//   button   : gambar + tombol/list native (bawaan)
//   rich     : pesan AI Rich (teks + tabel rapi) lalu tombol/list kategori
//   ads      : kartu thumbnail besar (externalAdReply) + tombol/list kategori
//   video    : video / GIF di header + tombol/list
//   doc      : dokumen + thumbnail besar + tombol/list
//   product  : pesan produk / katalog + tombol/list
//   carousel : kartu geser per kategori + tombol/list
const MENU_TYPES = {
    button: 'Gambar + tombol (bawaan)',
    rich: 'AI Rich: tabel kategori + tombol',
    ads: 'Kartu thumbnail besar + tombol',
    video: 'Video / GIF di header + tombol',
    doc: 'Dokumen + thumbnail besar + tombol',
    product: 'Pesan produk / katalog + tombol',
    carousel: 'Carousel: kartu geser per kategori'
}

const TYPE_ICON = {
    button: '🖼️',
    rich: '✨',
    ads: '📰',
    video: '🎬',
    doc: '📄',
    product: '🛍️',
    carousel: '🎠'
}

const typeStore = docStore('menuType', { type: 'button' })

const getMenuType = () => {
    const t = String(typeStore.get()?.type || 'button').toLowerCase()
    return MENU_TYPES[t] ? t : 'button'
}

const setMenuType = t => {
    typeStore.get().type = t
    typeStore.save()
}

// sumber media: string -> { url }, Buffer / object dipakai apa adanya
const mediaOf = src =>
    !src ? null : typeof src === 'string' ? { url: src } : src

// kartu thumbnail besar di atas pesan
function adCard(title, body) {
    const img = getMenuImage()
    if (!img) return undefined

    return {
        externalAdReply: {
            title,
            body,
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: false,
            ...(typeof img === 'string'
                ? { thumbnailUrl: img }
                : Buffer.isBuffer(img)
                    ? { thumbnail: img }
                    : img?.url
                        ? { thumbnailUrl: img.url }
                        : {}),
            sourceUrl: global.idSaluran
                ? CHANNEL_URL
                : ''
        }
    }
}

// markdown untuk pesan rich (pakai **tebal**)
const mdKv = (k, v) => `• ${k} : **${v}**`

const newsletterOpt = () =>
    global.idSaluran
        ? { newsletter: { name: global.nameSaluran, jid: global.idSaluran } }
        : {}

// ═══════════════ TIPE BARU: video / doc / product / carousel ═══════════════

const EXTRA_TYPES = ['video', 'doc', 'product', 'carousel']

// Kirim media header + tombol. Kalau sendButtons tidak menerima media itu,
// kirim media dulu lalu tombolnya di pesan terpisah.
async function sendMediaButtons(sock, jid, kind, media, opt, quoted) {
    const { text, footer, buttons, mentions, contextInfo, extra = {} } = opt

    try {
        await sock.sendButtons(jid, {
            [kind]: media,
            ...extra,
            text,
            footer,
            mentions,
            ...(contextInfo ? { contextInfo } : {}),
            buttons
        }, { quoted })

        return
    } catch (e) {
        console.error(`[MENU] sendButtons + ${kind} gagal, kirim terpisah:`, e.message)
    }

    await sock.sendMessage(jid, {
        [kind]: media,
        ...extra,
        caption: text.length > CAPTION_MAX ? text.slice(0, CAPTION_MAX) : text,
        mentions,
        ...(contextInfo ? { contextInfo } : {})
    }, { quoted })

    await sock.sendButtons(jid, {
        text: 'Pilih menu di bawah 👇',
        footer,
        buttons
    })
}

// carousel: tiap kartu = gambar + judul + isi + tombol
async function sendCarousel(sock, jid, { text, footer, cards }, quoted) {
    const img = mediaOf(getMenuImage())
    let media = null

    // upload gambar cukup sekali, dipakai semua kartu
    if (img) {
        media = await prepareWAMessageMedia(
            { image: img },
            { upload: sock.waUploadToServer }
        )
    }

    const IM = proto.Message.InteractiveMessage

    const built = cards.map(c => IM.fromObject({
        header: IM.Header.fromObject({
            title: c.title,
            hasMediaAttachment: !!media,
            ...(media || {})
        }),
        body: IM.Body.fromObject({ text: c.body }),
        footer: IM.Footer.fromObject({ text: c.footer || footer }),
        nativeFlowMessage: IM.NativeFlowMessage.fromObject({
            buttons: c.buttons.map(b => ({
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: b.text,
                    id: b.id
                })
            }))
        })
    }))

    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: IM.fromObject({
                    body: IM.Body.fromObject({ text }),
                    footer: IM.Footer.fromObject({ text: footer }),
                    carouselMessage: IM.CarouselMessage.fromObject({
                        cards: built,
                        messageVersion: 1
                    })
                })
            }
        }
    }, { quoted, userJid: sock.user?.id })

    await sock.relayMessage(jid, msg.message, { messageId: msg.key.id })
}

// kartu carousel: menu utama (10 kategori per halaman)
function carouselMainCards(groups, p, page) {
    const pages = Math.max(1, Math.ceil(groups.length / CAROUSEL_PER_PAGE))
    const now = Math.min(Math.max(page, 1), pages)

    const cards = groups
        .slice((now - 1) * CAROUSEL_PER_PAGE, now * CAROUSEL_PER_PAGE)
        .map(g => {
            const cmds = [...new Set(g.items.flat())].sort((a, b) => a.localeCompare(b))
            const preview = cmds.slice(0, 5).map(c => `⌬ ${p}${c}`).join('\n')

            return {
                title: catLabel(g.cat),
                body: `${g.total} command\n${preview}${cmds.length > 5 ? '\n...' : ''}`,
                buttons: [{ text: `📂 Buka ${catTitle(g.cat)}`, id: `${p}menu ${g.cat}` }]
            }
        })

    return { cards, page: now, pages }
}

// kartu carousel: isi satu kategori (20 command per kartu)
function carouselCatCards(category, p) {
    const cmds = [...new Set(category.items.flat())].sort((a, b) => a.localeCompare(b))
    const parts = chunk(cmds, CAROUSEL_CMD_PER_CARD)
    const shown = parts.slice(0, CAROUSEL_PER_PAGE)

    return shown.map((list, i) => ({
        title: `${iconOf(category.cat)} ${catTitle(category.cat)} (${i + 1}/${parts.length})`,
        body: list.map(c => `⌬ ${p}${c}`).join('\n'),
        buttons: [{ text: '🏠 Menu Utama', id: `${p}menu` }]
    }))
}

// Kirim salah satu tipe baru. Lempar error kalau gagal -> pemanggil fallback ke tipe button.
//   c.text     : isi pesan (caption / body)
//   c.buttons  : tombol/list yang dipasang
//   c.category : (opsional) kalau ini menu satu kategori
async function sendExtraType(type, c) {
    const { sock, jid, m, p, botName, title, sub, text, buttons } = c

    if (type === 'video') {
        const v = getMenuVideo()
        if (!v) throw new Error('global.videoMenu belum diisi di config.js')

        return sendMediaButtons(sock, jid, 'video', mediaOf(v), {
            text,
            footer: botName,
            buttons,
            mentions: [m.sender],
            extra: { gifPlayback: true }
        }, m)
    }

    if (type === 'doc') {
        const src = getMenuDoc()

        return sendMediaButtons(sock, jid, 'document', src ? mediaOf(src) : Buffer.from(`${botName} Menu`), {
            text,
            footer: botName,
            buttons,
            mentions: [m.sender],
            contextInfo: adCard(title, sub),
            extra: {
                fileName: `${botName} Menu.pdf`,
                mimetype: 'application/pdf',
                pageCount: 2026,
                fileLength: 99999999999
            }
        }, m)
    }

    if (type === 'product') {
        const img = mediaOf(getMenuImage())
        if (!img) throw new Error('tipe product butuh global.thumb.menu / utama')

        const ownerJid = sock.user?.id
            ? `${String(sock.user.id).split(':')[0].split('@')[0]}@s.whatsapp.net`
            : jid

        await sock.sendMessage(jid, {
            product: {
                productImage: img,
                productId: 'kaguya-menu',
                title,
                description: sub,
                currencyCode: 'IDR',
                priceAmount1000: 0,
                retailerId: botName,
                url: CHANNEL_URL,
                productImageCount: 1
            },
            businessOwnerJid: ownerJid,
            body: text.length > CAPTION_MAX ? text.slice(0, CAPTION_MAX) : text,
            footer: botName,
            mentions: [m.sender]
        }, { quoted: m })

        return sock.sendButtons(jid, {
            text: 'Pilih menu di bawah 👇',
            footer: botName,
            buttons
        })
    }

    if (type === 'carousel') {
        let cards
        const nav = []

        if (c.category) {
            cards = carouselCatCards(c.category, p)
        } else {
            const r = carouselMainCards(c.groups, p, c.page)
            cards = r.cards

            if (r.now > 1) nav.push({ type: 'reply', text: '◀ Sebelumnya', id: `${p}menu hal${r.now - 1}` })
            if (r.now < r.pages) nav.push({ type: 'reply', text: 'Berikutnya ▶', id: `${p}menu hal${r.now + 1}` })
        }

        await sendCarousel(sock, jid, { text, footer: botName, cards }, m)

        // iOS tidak punya list: pakai tombol pintasan saja (kategori ada di kartu)
        const base = c.ios ? quickButtons(p) : buttons

        return sock.sendButtons(jid, {
            text: c.navText || 'Geser kartu di atas, atau pilih lewat tombol 👇',
            footer: botName,
            buttons: [...nav, ...base]
        })
    }

    throw new Error(`tipe ${type} tidak dikenal`)
}

// ═══════════════ PILIH TIPE MENU (.menutype) ═══════════════

// Kirim pesan + tombol pilihan tipe. Android: list, iOS: tombol reply, Telegram: inline keyboard.
async function sendTypeChooser(sock, jid, m, { text, p, now, ios }) {
    if (sock.platform === 'telegram') {
        const btns = Object.keys(MENU_TYPES).map(k =>
            ({ text: `${k === now ? '✅ ' : ''}${TYPE_ICON[k]} ${k}`, callback_data: `${p}menutype ${k}` })
        )

        return sock.sendMessage(jid, {
            text,
            _markup: { inline_keyboard: tgRows(btns, 2) }
        }, { quoted: m })
    }

    const buttons = ios
        ? Object.keys(MENU_TYPES).map(k => ({
            type: 'reply',
            text: `${k === now ? '✅ ' : ''}${TYPE_ICON[k]} ${k}`,
            id: `${p}menutype ${k}`
        }))
        : [{
            type: 'list',
            text: '🎛️ Pilih Tipe Menu',
            sections: [{
                title: 'Tipe Pesan Menu',
                rows: Object.entries(MENU_TYPES).map(([k, v]) => ({
                    title: `${k === now ? '✅ ' : ''}${TYPE_ICON[k]} ${k}`,
                    description: v,
                    id: `${p}menutype ${k}`
                }))
            }]
        }]

    try {
        return await sock.sendButtons(jid, {
            text,
            footer: global.namebot || 'Bot',
            buttons
        }, { quoted: m })
    } catch (e) {
        console.error('[MENU] Gagal kirim tombol menutype, pakai teks:', e.message)
        return sock.sendMessage(jid, { text }, { quoted: m })
    }
}

// ═══════════════ MENU TELEGRAM ═══════════════
// Tampilan khusus Telegram: ringkas, kategori berupa tombol inline (3 per baris),
// daftar command rata dalam blok monospace, ada halaman kalau kategorinya panjang.
// Teks ditulis gaya WhatsApp (*tebal*, ```blok```); adapter Telegram yang mengubahnya ke HTML.

const TG_PER_PAGE = 40      // command per halaman
const TG_MSG_MAX = 3500     // batas aman satu pesan (limit Telegram 4096)
const TG_CAPTION_MAX = 1000 // batas caption foto (limit Telegram 1024)

// buang penanda format dari nama user supaya tidak merusak tampilan
const tgSafe = t => String(t || '').replace(/[*_~`]/g, '').trim() || 'Kak'

const tgFlat = items =>
    [...new Set(items.flat())].sort((a, b) => a.localeCompare(b))

// blok monospace 2 kolom (1 kolom kalau ada command yang panjang)
function tgGrid(cmds, p) {
    const items = cmds.map(c => `${p}${c}`)
    const w = Math.max(...items.map(s => s.length))
    const cols = w <= 16 ? 2 : 1
    const rows = []

    for (let i = 0; i < items.length; i += cols) {
        rows.push(
            items.slice(i, i + cols)
                .map((s, j, a) => (j < a.length - 1 ? s.padEnd(w) : s))
                .join('  ')
        )
    }

    return '```\n' + rows.join('\n') + '\n```'
}

// satu halaman kategori: judul + blok command
function tgSection(group, p, page = 1) {
    const cmds = tgFlat(group.items)
    const pages = Math.max(1, Math.ceil(cmds.length / TG_PER_PAGE))
    const now = Math.min(Math.max(page, 1), pages)
    const slice = cmds.slice((now - 1) * TG_PER_PAGE, now * TG_PER_PAGE)

    const title = `${iconOf(group.cat)} *${catTitle(group.cat)}*  -  ${cmds.length} command` +
        (pages > 1 ? `  -  hal ${now}/${pages}` : '')

    return { text: `${title}\n${tgGrid(slice, p)}`, page: now, pages }
}

// tombol: baris berisi beberapa tombol callback ("ditekan = user mengetik id-nya")
const tgBtn = (text, data) => ({ text, callback_data: data })

function tgRows(buttons, perRow) {
    const rows = []
    for (let i = 0; i < buttons.length; i += perRow) rows.push(buttons.slice(i, i + perRow))
    return rows
}

function tgMainKeyboard(groups, p, isOwner) {
    const cats = groups
        .filter(g => g.cat !== 'owner')
        .map(g => tgBtn(catLabel(g.cat), `${p}menu ${g.cat}`))

    const rows = tgRows(cats, 3)
    rows.push([tgBtn('📚 All Command', `${p}menu all`)])

    const owner = groups.find(g => g.cat === 'owner')
    const last = [tgBtn('👑 Kontak Owner', `${p}owner`)]
    if (owner && isOwner) last.unshift(tgBtn('🔐 Menu Owner', `${p}menu owner`))
    rows.push(last)

    return { inline_keyboard: rows }
}

function tgCategoryKeyboard(groups, cat, p, page, pages) {
    const rows = []

    if (pages > 1) {
        rows.push([
            tgBtn('◀ Sebelumnya', `${p}menu ${cat} ${page > 1 ? page - 1 : pages}`),
            tgBtn(`${page}/${pages}`, `${p}menu ${cat} ${page}`),
            tgBtn('Berikutnya ▶', `${p}menu ${cat} ${page < pages ? page + 1 : 1}`)
        ])
    }

    const i = groups.findIndex(g => g.cat === cat)
    const nav = []

    if (groups.length > 2) {
        const prev = groups[(i - 1 + groups.length) % groups.length]
        nav.push(tgBtn(`◀ ${catLabel(prev.cat)}`, `${p}menu ${prev.cat}`))
    }

    nav.push(tgBtn('🏠 Menu Utama', `${p}menu`))

    if (groups.length > 2) {
        const next = groups[(i + 1) % groups.length]
        nav.push(tgBtn(`${catLabel(next.cat)} ▶`, `${p}menu ${next.cat}`))
    }

    rows.push(nav)
    return { inline_keyboard: rows }
}

async function telegramMenu(m, { sock, jid, prefix, isOwner, isPremium, text: argText, args }) {
    const p = prefix || primaryPrefix() || '.'
    const groups = collectCommands({ isOwner, isPremium, tgHidden: telegramHidden() })
    const send = (text, markup) =>
        sock.sendMessage(jid, { text, ...(markup ? { _markup: markup } : {}) }, { quoted: m })

    const query = String(
        argText ?? (Array.isArray(args) ? args.join(' ') : '') ?? ''
    ).trim().toLowerCase()

    const [qCat, qPage] = query.split(/\s+/)

    // ── semua command: dikelompokkan per kategori, dipecah per ~3500 karakter ──
    if (qCat === 'all') {
        const blocks = []

        for (const g of groups) {
            const pages = Math.max(1, Math.ceil(tgFlat(g.items).length / TG_PER_PAGE))
            for (let pg = 1; pg <= pages; pg++) blocks.push(tgSection(g, p, pg).text)
        }

        const messages = []
        let cur = ''

        for (const b of blocks) {
            if (cur && (cur.length + b.length + 2) > TG_MSG_MAX) {
                messages.push(cur)
                cur = ''
            }
            cur = cur ? `${cur}\n\n${b}` : b
        }
        if (cur) messages.push(cur)

        for (const [i, msg] of messages.entries()) {
            const last = i === messages.length - 1
            await send(msg, last ? { inline_keyboard: [[tgBtn('🏠 Menu Utama', `${p}menu`)]] } : undefined)
        }
        return
    }

    // ── satu kategori ──
    if (qCat && !/^(hal|halaman|page)\d*$/.test(qCat)) {
        const group = groups.find(g => g.cat === qCat)

        if (!group) {
            return send(
                `Kategori *${tgSafe(qCat)}* tidak ditemukan.\n\nPilih dari tombol di bawah atau ketik ${p}menu.`,
                tgMainKeyboard(groups, p, isOwner)
            )
        }

        const sec = tgSection(group, p, Number(qPage) || 1)

        return send(
            `${sec.text}\n\nKetik ${p}menu untuk kembali.`,
            tgCategoryKeyboard(groups, group.cat, p, sec.page, sec.pages)
        )
    }

    // ── menu utama ──
    const total = new Set(groups.flatMap(g => g.items.flat())).size
    const access = isOwner ? 'Owner' : isPremium ? 'Premium' : 'Free'
    const name = tgSafe(m.pushName)
    const botName = tgSafe(global.namebot || 'Bot')
    const mode = global.isPublic?.('telegram') ? 'Public' : 'Self'

    let caption = [
        `${greet()}, *${name}* 🪸`,
        `Aku *${botName}*, asisten bot di Telegram.`,
        '',
        '🤖 *Info Bot*',
        `- Prefix  : ${p}  (atau /)`,
        `- Mode    : ${mode}`,
        `- Command : ${total}`,
        `- Aktif   : ${longRuntime(process.uptime())}`,
        '',
        '👤 *Kamu*',
        `- Status  : ${access}`,
        `- ID      : \`${String(m.sender).split('@')[0]}\``,
        '',
        'Pilih kategori di bawah.'
    ].join('\n')

    const markup = tgMainKeyboard(groups, p, isOwner)
    const img = getMenuImage()
    const photo = img ? (typeof img === 'string' ? { url: img } : img) : null

    if (photo && caption.length <= TG_CAPTION_MAX) {
        try {
            return await sock.sendMessage(jid, { image: photo, caption, _markup: markup }, { quoted: m })
        } catch (e) {
            console.error('[MENU] Telegram: gagal kirim foto menu, pakai teks:', e.message)
        }
    }

    return send(caption, markup)
}

// ───────── plugin menu ─────────

let handler = async (
    m,
    {
        sock,
        jid,
        prefix,
        isOwner,
        isPremium,
        text: argText,
        args,
        command,
        reply
    }
) => {
    // .menutype — pilih jenis pesan menu (owner), pilihan lewat tombol
    if (String(command || '').toLowerCase() === 'menutype') {
        const q = String(argText ?? (Array.isArray(args) ? args.join(' ') : '') ?? '').trim().toLowerCase()
        const p0 = prefix || primaryPrefix() || '.'
        const now = getMenuType()
        const ios0 = isIosMessage(m)
        const listTypes = Object.entries(MENU_TYPES)
            .map(([k, v]) => `${k === now ? '✅' : '▫️'} ${TYPE_ICON[k]} *${k}* — ${v}`).join('\n')

        if (!q) {
            return sendTypeChooser(sock, jid, m, {
                text: `*Tipe pesan menu*\n\n${listTypes}\n\nPilih tipe lewat tombol di bawah 👇`,
                p: p0,
                now,
                ios: ios0
            })
        }

        if (!isOwner) return reply('Hanya owner yang bisa mengganti tipe menu.')

        if (!MENU_TYPES[q]) {
            return sendTypeChooser(sock, jid, m, {
                text: `Tipe *${q}* tidak ada.\n\n${listTypes}\n\nPilih tipe lewat tombol di bawah 👇`,
                p: p0,
                now,
                ios: ios0
            })
        }

        setMenuType(q)

        // peringatan kalau tipe butuh konfigurasi yang belum diisi
        const warn =
            q === 'video' && !getMenuVideo()
                ? '\n\n⚠️ Isi *global.videoMenu* di config.js (link mp4), kalau kosong menu otomatis pakai tipe bawaan.'
                : q === 'product' && !getMenuImage()
                    ? '\n\n⚠️ Tipe product butuh *global.thumb.menu* / *utama*.'
                    : ''

        const okText = `✅ Tipe menu diganti ke ${TYPE_ICON[q]} *${q}* (${MENU_TYPES[q]}).${warn}`

        if (sock.platform === 'telegram') {
            return sock.sendMessage(jid, {
                text: okText,
                _markup: {
                    inline_keyboard: [[
                        tgBtn('📋 Coba Menu', `${p0}menu`),
                        tgBtn('🎛️ Ganti Tipe', `${p0}menutype`)
                    ]]
                }
            }, { quoted: m })
        }

        try {
            return await sock.sendButtons(jid, {
                text: okText,
                footer: global.namebot || 'Bot',
                buttons: [
                    { type: 'reply', text: '📋 Coba Menu', id: `${p0}menu` },
                    { type: 'reply', text: '🎛️ Ganti Tipe', id: `${p0}menutype` }
                ]
            }, { quoted: m })
        } catch (e) {
            console.error('[MENU] Gagal kirim tombol konfirmasi menutype:', e.message)
            return reply(`${okText}\nCoba ketik ${p0}menu`)
        }
    }

    // Telegram punya tampilan sendiri (lihat telegramMenu)
    if (sock.platform === 'telegram') {
        return telegramMenu(m, { sock, jid, prefix, isOwner, isPremium, text: argText, args })
    }

    const p = prefix || primaryPrefix() || '.'
    const pushname = m.pushName || 'No Name'
    const ios = isIosMessage(m)
    const info = getScriptInfo()
    const rpg = await getRpgInfo(sock, m, { isOwner, isPremium })
    const allGroups = collectCommands({ isOwner, isPremium })

    // ───────── argumen menu ─────────

    const query = String(
        argText ?? (Array.isArray(args) ? args.join(' ') : '') ?? ''
    ).trim().toLowerCase()

    const pageMatch = query.match(/^(?:hal|halaman|page)\s*(\d+)$/)
    const showAll = query === 'all'
    const showMain = !query || !!pageMatch

    let category = null

    if (!showMain && !showAll) {
        category = allGroups.find(g => g.cat === query)

        if (!category) {
            return sock.sendMessage(jid, {
                text: [
                    box('kategori tidak ada', [
                        `◦ *${query}* tidak ditemukan`
                    ]),
                    '',
                    box('tersedia', allGroups.map(g => `${iconOf(g.cat)} ${g.cat}`)),
                    '',
                    font(`ketik ${p}menu untuk melihat daftar menu`)
                ].join('\n')
            }, { quoted: m })
        }
    }

    const access = isOwner ? 'Owner' : isPremium ? 'Premium' : 'Free'
    const senderPn = await toPN(sock, m.sender).catch(() => m.sender)
    const number = String(senderPn || '')
        .split('@')[0]
        .split(':')[0]
        .replace(/\D/g, '') || '-'

    // ───────── header ─────────

    const botName = global.namebot || 'Bot'
    const level = rpg?.level ?? 0
    const pluginTotal = pluginCount()
    const mode = (global.isPublic ? global.isPublic('whatsapp') : !global.selfmode) ? 'Public' : 'Self'

    const intro = [
        `${greet()}, *${pushname}* 🪸`,
        font(`i am ${botName}, your personal assistant on whatsapp. pick a category below to explore every feature.`)
    ].join('\n')

    const introAll = [
        `${greet()}, *${pushname}* 🪸`,
        font('here is the complete list of every *command* in this bot!')
    ].join('\n')

    // ringkas untuk menu utama (supaya muat di body tombol)
    const botRowsShort = [
        kv('bot', botName),
        kv('owner', getCreator() || '-'),
        kv('prefix', p),
        kv('mode', mode.toLowerCase()),
        kv('uptime', longRuntime(process.uptime())),
        kv('commands', info.total)
    ]

    // lengkap untuk menu all
    const botRowsFull = [
        kv('bot name', botName),
        kv('creator', getCreator() || '-'),
        kv('prefix', p),
        kv('mode', mode.toLowerCase()),
        kv('version', info.botVersion),
        kv('runtime', longRuntime(process.uptime())),
        kv('library', info.library),
        kv('commands', info.total)
    ]

    const userRows = [
        kv('name', pushname),
        kv('number', number),
        kv('operator', operatorOf(number)),
        kv('status', access.toLowerCase() === 'free' ? 'free user' : access.toLowerCase()),
        kv('level', `${level} (${rankOf(level).toLowerCase()})`),
        kv('exp', rpg?.exp ?? 0),
        kv('limit', rpg?.limit ?? (isOwner || isPremium ? '∞' : 0)),
        kv('balance', `Rp ${rpg?.money ?? 0}`)
    ]

    const botInfo = box('bot info', [...botRowsShort, kv('plugins', pluginTotal)])
    const userInfo = box('user info', userRows)

    // Menu all: sama seperti menu awal, plugins cukup jumlahnya (bot murni ESM, tanpa case)
    const botInfoAll = box('bot info', [
        ...botRowsFull,
        kv('plugins', pluginTotal)
    ])

    const header = [intro, botInfo, userInfo].join('\n\n')
    const headerAll = [introAll, botInfoAll, userInfo].join('\n\n')
    const headerShort = [intro, userInfo].join('\n\n')
    const footer = [
        font(`› use  : ${p}menu [category]`),
        font(`› ex   : ${p}menu all`)
    ].join('\n')

    const cmdLines = list => list.map(c => item(p, c))
    const cmdCols = list =>
        chunk(list, 2).map(r => r.map(c => item(p, c)).join('   '))

    // kotak satu kategori: ikon + nama + jumlah command
    const boxOf = (cat, total, lines) =>
        [`╭─「 ${iconOf(cat)} ${font(`menu ${cat}`)} · ${total} 」`, ...lines.map(l => `│ ${l}`), LINE].join('\n')

    const listOf = groups =>
        groups
            .map(({ cat, items, total }) =>
                boxOf(cat, total, cmdLines(items.flat()))
            )
            .join('\n\n')

    // ───────── kategori dalam teks ─────────

    const categoryText = box('cmd category', [
        '📚 all',
        ...allGroups.map(g => `${iconOf(g.cat)} ${g.cat} (${g.total})`)
    ])

    const sendMainVN = async () => {
        const url = getAudioUrl()
        if (!/^https?:\/\//i.test(url)) return

        try {
            await sendVN(sock, jid, url, m)
        } catch (e) {
            console.error('[MENU] Gagal kirim VN:', e.message)
        }
    }

    const sendPhotoMenu = async (listText, head = header) => {
        const img = getMenuImage()
        const photo = img
            ? (typeof img === 'string' ? { url: img } : img)
            : null

        const full = [head, listText, footer].filter(Boolean).join('\n\n')

        if (photo && full.length <= CAPTION_MAX) {
            try {
                return await sock.sendMessage(jid, {
                    image: photo,
                    caption: full,
                    mentions: [m.sender]
                }, { quoted: m })
            } catch (e) {
                console.error(
                    '[MENU] Gagal kirim foto+daftar dalam satu pesan:',
                    e.message
                )
            }
        }

        let photoSent = false

        if (photo) {
            try {
                await sock.sendMessage(jid, {
                    image: photo,
                    caption: head.length > BODY_MAX ? headerShort : head,
                    mentions: [m.sender]
                }, { quoted: m })

                photoSent = true
            } catch (e) {
                console.error('[MENU] Gagal kirim foto menu:', e.message)
            }
        }

        const parts = photoSent
            ? [listText, footer]
            : [head, listText, footer]

        await sock.sendMessage(jid, {
            text: parts.filter(Boolean).join('\n\n')
        }, photoSent ? undefined : { quoted: m })
    }

    // ───────── semua fitur ─────────

    if (showAll) {
        const full = [headerAll, listOf(allGroups), footer]
            .filter(Boolean)
            .join('\n\n')

        const tombolAll = ios
            ? [
                { type: 'reply', text: '🏠 Menu Utama', id: `${p}menu` },
                ...quickButtons(p)
            ]
            : [
                ...androidButtons(allGroups, p),
                { type: 'reply', text: '🏠 Menu Utama', id: `${p}menu` },
                ...quickButtons(p)
            ]

        let sent = false

        if (getMenuImage() && full.length <= TEXT_MAX) {
            try {
                await sock.sendButtons(jid, {
                    image: getMenuImage(),
                    text: full,
                    footer: botName,
                    mentions: [m.sender],
                    buttons: tombolAll
                }, { quoted: m })

                sent = true
            } catch (e) {
                console.error('[MENU] Gagal kirim menu all + foto + tombol:', e.message)
            }
        }

        const img = getMenuImage()
        const contextInfo = img
            ? {
                externalAdReply: {
                    title: `${botName} — All Menu`,
                    body: `${info.total} command`,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    showAdAttribution: false,
                    ...(typeof img === 'string'
                        ? { thumbnailUrl: img }
                        : Buffer.isBuffer(img)
                            ? { thumbnail: img }
                            : img?.url
                                ? { thumbnailUrl: img.url }
                                : {}),
                    sourceUrl: global.idSaluran
                        ? CHANNEL_URL
                        : ''
                }
            }
            : undefined

        if (!sent && full.length <= TEXT_MAX) {
            try {
                await sock.sendButtons(jid, {
                    text: full,
                    footer: botName,
                    mentions: [m.sender],
                    ...(contextInfo ? { contextInfo } : {}),
                    buttons: tombolAll
                }, { quoted: m })

                sent = true
            } catch (e) {
                console.error('[MENU] Gagal kirim menu all + tombol:', e.message)
            }
        }

        if (!sent) {
            if (full.length <= TEXT_MAX) {
                await sock.sendMessage(jid, {
                    text: full,
                    mentions: [m.sender],
                    ...(contextInfo ? { contextInfo } : {})
                }, { quoted: m })
            } else {
                await sendPhotoMenu(listOf(allGroups), headerAll)
            }
        }

        return sendMainVN()
    }

    // ───────── satu kategori ─────────

    if (category) {
        const tombol = ios
            ? iosCategoryButtons(allGroups, category.cat, p)
            : [
                ...androidButtons(allGroups, p),
                { type: 'reply', text: '🏠 Menu Utama', id: `${p}menu` },
                ...quickButtons(p)
            ]

        const flat = category.items.flat()
        const join = (...parts) => parts.filter(Boolean).join('\n\n')
        const fits = t => t.length <= CAPTION_MAX
        const sec = (list, fn) => boxOf(category.cat, category.total, fn(list))

        const catIntro = [
            `${font('hi')} *${pushname}* ${iconOf(category.cat)}`,
            font(`here are all the commands in *menu ${category.cat}*`)
        ].join('\n')

        const catButtons = ios
            ? iosCategoryButtons(allGroups, category.cat, p)
            : [
                ...androidButtons(allGroups, p),
                { type: 'reply', text: '🏠 Menu Utama', id: `${p}menu` },
                ...quickButtons(p)
            ]
        const menuTypeCat = getMenuType()

        // teks kategori yang dipotong supaya muat caption (dipakai tipe button, video, doc, product)
        let teks = join(catIntro, userInfo, sec(flat, cmdLines), footer)
        if (!fits(teks)) teks = join(catIntro, sec(flat, cmdLines), footer)
        if (!fits(teks)) teks = join(catIntro, sec(flat, cmdCols), footer)

        if (!fits(teks)) {
            let n = flat.length

            while (n > 0 && !fits(teks)) {
                n -= 5
                const keep = Math.max(n, 0)
                teks = join(
                    catIntro,
                    sec(flat.slice(0, keep), cmdCols),
                    font(`...and ${flat.length - keep} more commands. use ${p}menu all`),
                    footer
                )
            }
        }

        // tipe RICH: tabel 3 kolom berisi command
        if (menuTypeCat === 'rich') {
            try {
                const cmds = [...new Set(flat)].sort((a, b) => a.localeCompare(b))
                const rows3 = chunk(cmds.map(c => `${p}${c}`), 3).map(r => [...r, '', ''].slice(0, 3))
                const tables = chunk(rows3, 40).map((rs, i, all) => ({
                    title: `${iconOf(category.cat)} ${catTitle(category.cat)} · ${category.total} command${all.length > 1 ? ` (${i + 1}/${all.length})` : ''}`,
                    headers: ['Perintah', 'Perintah', 'Perintah'],
                    rows: rs
                }))

                await sock.sendAIRich(jid, {
                    text: `Hai **${pushname}** ${iconOf(category.cat)}\nBerikut semua command di **menu ${category.cat}**.`,
                    tables,
                    buttons: catButtons,
                    buttonsText: `Ketik ${p}menu untuk kembali 👇`,
                    footer: botName,
                    image: getMenuImage(),
                    mentionedJid: [m.sender]
                }, { quoted: m })

                return
            } catch (e) {
                console.error('[MENU] Tipe rich (kategori) gagal, pakai tipe button:', e.message)
            }
        }

        // tipe ADS: kartu thumbnail besar
        if (menuTypeCat === 'ads') {
            try {
                const adText = join(catIntro, sec(flat, cmdCols), footer)
                const adBody = adText.length <= TEXT_MAX ? adText : join(catIntro, sec(flat.slice(0, 120), cmdCols), footer)

                await sock.sendButtons(jid, {
                    text: adBody,
                    footer: botName,
                    mentions: [m.sender],
                    contextInfo: adCard(`${botName} — ${catTitle(category.cat)}`, `${category.total} command`),
                    buttons: catButtons
                }, { quoted: m })

                return
            } catch (e) {
                console.error('[MENU] Tipe ads (kategori) gagal, pakai tipe button:', e.message)
            }
        }

        // tipe VIDEO / DOC / PRODUCT / CAROUSEL
        if (EXTRA_TYPES.includes(menuTypeCat)) {
            try {
                await sendExtraType(menuTypeCat, {
                    sock, jid, m, p, ios, botName,
                    category,
                    title: `${botName} — ${catTitle(category.cat)}`,
                    sub: `${category.total} command`,
                    text: menuTypeCat === 'carousel'
                        ? `${catIntro}\n\n${font(`${category.total} command in ${category.cat}. swipe the cards.`)}`
                        : teks,
                    buttons: catButtons
                })

                return
            } catch (e) {
                console.error(`[MENU] Tipe ${menuTypeCat} (kategori) gagal, pakai tipe button:`, e.message)
            }
        }

        try {
            await sock.sendButtons(jid, {
                image: getMenuImage(),
                text: teks,
                footer: botName,
                mentions: [m.sender],
                buttons: tombol
            }, { quoted: m })
        } catch (e) {
            console.error('[MENU] Gagal kirim menu kategori + tombol, pakai teks:', e.message)
            await sendPhotoMenu(listOf([category]))
        }

        return
    }

    // ───────── menu utama ─────────

    const page = pageMatch ? Number(pageMatch[1]) : 1
    const menuType = getMenuType()

    // tombol utama (dipakai tipe rich, ads, dan tipe baru)
    const mainButtons = () => ios
        ? iosMainButtons(allGroups, p, page).buttons
        : [...androidButtons(allGroups, p), ...quickButtons(p)]

    // tipe RICH: pesan AI Rich berisi tabel kategori, disusul gambar + tombol
    if (menuType === 'rich') {
        try {
            const rows = allGroups.map((g, i) => [
                String(i + 1),
                `${iconOf(g.cat)} ${catTitle(g.cat)}`,
                String(g.total),
                `${p}menu ${g.cat}`
            ])

            await sock.sendAIRich(jid, {
                text: [
                    `${greet()}, **${pushname}** 🪸`,
                    `Aku **${botName}**, asisten WhatsApp pribadimu. Pilih kategori di tabel atau lewat tombol.`,
                    '',
                    mdKv('Prefix', p),
                    mdKv('Mode', mode),
                    mdKv('Uptime', longRuntime(process.uptime())),
                    mdKv('Command', info.total),
                    mdKv('Status', access),
                    mdKv('Level', `${level} (${rankOf(level)})`),
                    mdKv('Limit', rpg?.limit ?? (isOwner || isPremium ? '∞' : 0))
                ].join('\n'),
                table: {
                    title: 'Kategori Menu',
                    headers: ['No', 'Kategori', 'Cmd', 'Ketik'],
                    rows
                },
                buttons: mainButtons(),
                buttonsText: `Ketik ${p}menu all untuk semua fitur 👇`,
                footer: botName,
                image: getMenuImage(),
                mentionedJid: [m.sender]
            }, { quoted: m })

            if (!pageMatch || page === 1) return sendMainVN()
            return
        } catch (e) {
            console.error('[MENU] Tipe rich gagal, pakai tipe button:', e.message)
        }
    }

    // tipe ADS: kartu thumbnail besar + tombol
    if (menuType === 'ads') {
        try {
            await sock.sendButtons(jid, {
                text: header.length > BODY_MAX * 2 ? headerShort : header,
                footer: botName,
                mentions: [m.sender],
                contextInfo: adCard(botName, `${info.total} command • prefix ${p}`),
                buttons: mainButtons()
            }, { quoted: m })

            if (!pageMatch || page === 1) return sendMainVN()
            return
        } catch (e) {
            console.error('[MENU] Tipe ads gagal, pakai tipe button:', e.message)
        }
    }

    // tipe VIDEO / DOC / PRODUCT / CAROUSEL
    if (EXTRA_TYPES.includes(menuType)) {
        try {
            await sendExtraType(menuType, {
                sock, jid, m, p, ios, botName,
                groups: allGroups,
                page,
                title: botName,
                sub: `${info.total} command • prefix ${p}`,
                text: header.length > CAPTION_MAX ? headerShort : header,
                buttons: mainButtons()
            })

            if (!pageMatch || page === 1) return sendMainVN()
            return
        } catch (e) {
            console.error(`[MENU] Tipe ${menuType} gagal, pakai tipe button:`, e.message)
        }
    }

    let buttons
    let body

    if (ios) {
        const r = iosMainButtons(allGroups, p, page)

        buttons = r.buttons
        body =
            `${header}\n\n` +
            font(`page ${r.page}/${r.pages} • ${p}menu all for all features`)

        if (body.length > BODY_MAX) {
            body =
                `${headerShort}\n\n` +
                font(`page ${r.page}/${r.pages} • ${p}menu all for all features`)
        }
    } else {
        buttons = [...androidButtons(allGroups, p), ...quickButtons(p)]
        body = header

        if (body.length > BODY_MAX) body = headerShort
    }

    try {
        await sock.sendButtons(jid, {
            image: getMenuImage(),
            text: body,
            footer: `YannRzy Tech`,
            mentions: [m.sender],
            ...(ios ? {} : { ...newsletterOpt(), business: true }),
            buttons
        }, { quoted: m })
    } catch (e) {
        console.error('[MENU] Gagal kirim tombol menu, pakai teks:', e.message)

        const fallback = [header, categoryText, footer]
            .filter(Boolean)
            .join('\n\n')

        const short = fallback.length <= 1000

        try {
            const img = getMenuImage()
            const photo = img
                ? (typeof img === 'string' ? { url: img } : img)
                : null

            if (photo) {
                await sock.sendMessage(jid, {
                    image: photo,
                    caption: short ? fallback : header
                }, { quoted: m })
            } else {
                await sock.sendMessage(jid, {
                    text: short ? fallback : header
                }, { quoted: m })
            }

            if (!short) {
                await sock.sendMessage(jid, {
                    text: [categoryText, footer].filter(Boolean).join('\n\n')
                })
            }
        } catch {
            await sock.sendMessage(jid, {
                text: fallback
            }, { quoted: m })
        }
    }

    if (!pageMatch || page === 1) return sendMainVN()
}

handler.command = ['menu', 'menutype']
handler.subs = ['help']
handler.tags = ['main']

export default handler
