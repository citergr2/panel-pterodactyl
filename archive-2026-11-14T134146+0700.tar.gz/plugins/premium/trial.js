
/**

* Kaguya Multi Device — WhatsApp & Tele Bot
* 
* Library      : whiskeysockets baileys
* Type         : Plugins | ESM Modules
* Creator      : YannRzy Tech
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VaoMGuLA89MbfGh62V16
* 
* Copyright © YannRzy Tech 2026
* All Rights Reserved.
  */


import { getMeta } from '../../lib/platform/wa.js'
import { klaimTrial } from '../../lib/rpg/extra.js'
import { formatRemaining, formatDate } from '../../lib/core/data.js'

let handler = async (m, { sock, reply, sender, jid }) => {
    const meta = m.isGroup ? await getMeta(sock, jid).catch(() => null) : null
    const r = await klaimTrial(sock, m, sender, meta)
    if (!r.ok) return reply(`⚠️ ${r.msg}`)
    await reply(
        `🎉 *TRIAL PREMIUM AKTIF*\n\nDurasi: *${r.hari} hari*\nSisa: ${formatRemaining(r.until)}\nBerakhir: ${formatDate(r.until)}\n\nSelama trial semua command premium dan limit tanpa batas bisa dipakai. Kamu akan diingatkan sebelum habis.`
    )
}

handler.help = ['trial']
handler.tags = ['premium']
handler.command = ['trial']
export default handler
