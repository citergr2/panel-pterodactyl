/**

* Kaguya Multi Device — WhatsApp & Tele Bot
* 
* Library      : whiskeysockets baileys
* Type         : Plugins | ESM Modules
* Creator      : YannRzy Tech
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VaoMGuLA89MbfGh62V16
* 
* Copyright © YannRzy Tech 2026
* All Rights Reserved.
  */


const ENDPOINT = 'https://token-netflix.vercel.app/api/generate'
const CREATOR = 'YannRzy'

function buildLinks(token) {
    return {
        browser: `https://www.netflix.com/login?nftoken=${token}`,
        mobile: `https://netflix.com/unsupported?nftoken=${token}`,
        tv: `https://www.netflix.com/tv?nftoken=${token}`,
        pc: `https://www.netflix.com/browse?nftoken=${token}`
    }
}

async function generateNetflix(count) {
    const res = await fetch(ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ count, stream: false })
    })
    if (!res.ok) throw new Error(`API balas status ${res.status}`)
    return res.json()
}

let handler = async (m, { reply, sock, text, prefix }) => {
    const p = prefix || '.'
    const count = parseInt((text || '').trim().split(/\s+/)[0]) || 1
    if (count < 1 || count > 5) return reply(`Contoh: ${p}nfgen 1\n(maksimal 5 sekaligus)`)

    await reply(`⏳ Generating ${count} token by ${CREATOR}...`)

    let result
    try {
        result = await generateNetflix(count)
    } catch (e) {
        return reply(`❌ Gagal menghubungi API: ${e.message}`)
    }

    const tokens = result.data || []
    if (!tokens.length) return reply(`❌ Stok habis / API error\n${JSON.stringify(result).slice(0, 1000)}`)

    const sukses = tokens.filter(t => t.success).length

    let txt = `⚔ *NETFLIX-TOKEN*\n\n`
    txt += `┌─ *Ringkasan Hasil*\n`
    txt += `│ ◦ Status : true\n`
    txt += `│ ◦ Negara : Indonesia (ID)\n`
    txt += `│ ◦ Stok : ${sukses} tersisa\n`
    txt += `│ ◦ Total : ${sukses} / ${count}\n`
    txt += `└\n\n`
    txt += `┌─ *Daftar Token VIP*\n`

    tokens.forEach((item, idx) => {
        if (!item.success) return
        const links = buildLinks(item.token)
        const pr = item.profile || {}

        txt += `│\n`
        txt += `│ ${idx + 1}. Token:\n`
        txt += `│ ${item.token}\n`
        txt += `│\n`
        txt += `│ ◦ Country : ${pr.country || 'ID'}\n`
        txt += `│ ◦ Name : ${pr.countryName || 'Indonesia'}\n`
        txt += `│ ◦ Remaining : ${pr.remaining ?? 0}\n`
        txt += `│ ◦ Status : ${pr.status || 'Active'}\n`
        txt += `│ ◦ Email : ${pr.email || 'yo***@gmail.com'}\n`
        txt += `│ ◦ Plan : ${pr.plan || 'Premium'}\n`
        txt += `│ ◦ Country : ${pr.country || 'ID'}\n`
        txt += `│ ◦ Payments : ${pr.payments || '•••••' + (pr.last4 || '5076')}\n`
        txt += `│ ◦ Next Billing: ${pr.nextBilling || '5 November 2026'}\n`
        txt += `│ ◦ Member Since: ${pr.memberSince || 'November 2023'}\n`
        txt += `│ ◦ Phone : ${pr.phone || '0821-7650-****'}\n`
        txt += `│ ◦ Connection : ${pr.connection || '4 devices · UHD'}\n`
        txt += `│ ◦ Profiles : ${pr.profiles || 5}\n`
        txt += `│ ◦ Profile Sub-System: ${pr.profileSystem || '5 profiles'}\n`
        txt += `│ ◦ Expires : ${item.expiry ? new Date(item.expiry).toLocaleString() : '10/5/2026, 12:10:54 PM'}\n`
        txt += `│\n`
        txt += `│ ◦ Link Browser: ${links.browser}\n`
        txt += `│\n`
        txt += `│ ◦ Link Mobile : ${links.mobile}\n`
        txt += `│\n`
        txt += `│ ◦ Link TV : ${links.tv}\n`
    })

    txt += `└\n\n`
    txt += `_Creator: ${CREATOR} | ${result.time_ms || ''}ms_`

    return sock.sendMessage(m.chat, { text: txt }, { quoted: m })
}

handler.command = ['netflixprem', 'nf-gen']
handler.help = ['netflixprem <jumlah>']
handler.tags = ['premium']
handler.premium = true
handler.limit = true

export default handler
