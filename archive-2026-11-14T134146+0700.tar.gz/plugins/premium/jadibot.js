/**

* Kaguya Multi Device — WhatsApp & Tele Bot
* 
* Library      : whiskeysockets baileys
* Type         : Plugins | ESM Modules
* Creator      : YannRzy Tech
* Recode       : (Your Name)
* 
* Official Channels:
* • https://whatsapp.com/channel/0029VaoMGuLA89MbfGh62V16
* 
* Copyright © YannRzy Tech 2026
* All Rights Reserved.
  */


import { startJadibot, stopJadibot, listJadibot, clones, buttonsToText } from '../../lib/platform/wa.js'
import { runtime, formatPhone } from '../../lib/core/system.js'

// batas sesi QR yang menunggu scan per user non-owner
const MAX_PENDING_QR = 2

const normalize = (raw) => String(raw || '').replace(/\D/g, '').replace(/^0/, '62')

const quick = (text, id) => ({ type: 'reply', text, id })

let handler = async (m, { sock, jid, text, command, reply, example, isOwner, usedPrefix, prefix }) => {
    const p = usedPrefix ?? prefix ?? '.'

    // kirim pesan dengan tombol; kalau tombol gagal, kirim teks biasa + daftar perintahnya
    const sendBtn = async (body, buttons) => {
        try {
            return await sock.sendButtons(jid, {
                text: body,
                footer: global.namebot || 'Kaguya',
                buttons
            }, { quoted: m })
        } catch {
            const extra = buttonsToText(buttons)
            return reply(extra ? `${body}\n\n${extra}` : body)
        }
    }

    // daftar sesi yang boleh dilihat user ini (owner: semua)
    const visibleSessions = () => listJadibot().filter((s) => isOwner || s.requester === m.sender)

    // tombol pilih sesi untuk dihentikan
    const stopPicker = (list) => ({
        type: 'single_select',
        text: '🛑 Stop Sesi',
        sections: [{
            title: 'Pilih sesi yang dihentikan',
            rows: list.slice(0, 20).map(({ number, pending, mode }) => ({
                title: pending ? `${number} (menunggu scan)` : formatPhone(number),
                description: mode === 'qr' ? 'via QR' : 'via pairing code',
                id: `${p}stopjadibot ${number}`
            }))
        }]
    })

    // ───── menu pilihan metode ─────
    if (command === 'jadibot' && !String(text || '').trim()) {
        return sendBtn(
            `*[ JADIBOT ]*\n\n` +
            `Pilih cara menyambungkan nomor:\n` +
            `• *Pairing Code* — masukkan nomor, dapat kode 8 karakter\n` +
            `• *QR Code* — scan QR dari WhatsApp, tanpa ketik nomor\n\n` +
            `Kedua cara bisa dipakai bersamaan untuk beberapa nomor.`,
            [
                quick('📱 Pairing Code', `${p}jadibotcode`),
                quick('📷 QR Code', `${p}jadibotqr`),
                quick('📋 List Jadibot', `${p}listjadibot`)
            ]
        )
    }

    // ───── petunjuk pairing code (butuh nomor) ─────
    if (command === 'jadibotcode') {
        return sendBtn(
            `*[ JADIBOT • PAIRING CODE ]*\n\n` +
            `Kirim perintah dengan nomor tujuan:\n` +
            `*${p}jadibot 628xxxxxxxxxx*\n\n` +
            `Tekan tombol di bawah untuk menyalin formatnya, lalu ganti nomornya.`,
            [
                { type: 'copy', text: '📋 Salin Format', code: `${p}jadibot 628` },
                quick('📷 Pakai QR Saja', `${p}jadibotqr`)
            ]
        )
    }

    // ───── jadibotqr: QR code (tanpa nomor) | jadibot 628xxx: pairing code ─────
    // Keduanya bisa dipakai bersamaan; tiap sesi berjalan sendiri-sendiri (dual connection).
    if (command === 'jadibot' || command === 'jadibotqr') {
        // "jadibot qr" = jalan pintas untuk jadibotqr
        const args = String(text || '').trim().split(/\s+/).filter(Boolean)
        const wantsQR = command === 'jadibotqr' || /^qr$/i.test(args[0] || '')

        if (wantsQR) {
            const mine = listJadibot().filter((s) => s.requester === m.sender && s.pending)
            if (!isOwner && mine.length >= MAX_PENDING_QR) {
                return sendBtn(
                    `Kamu masih punya ${mine.length} sesi QR yang belum di-scan. Scan atau batalkan dulu.`,
                    [stopPicker(mine)]
                )
            }

            await reply('Menyiapkan jadibot lewat QR, tunggu gambar QR-nya ya...')

            try {
                await startJadibot(null, { sock, jid, prefix: p }, m.sender, 'qr')
            } catch (e) {
                await reply(`Gagal memulai jadibot QR: ${e.message}`)
            }
            return
        }

        const number = normalize(text)
        if (!number || number.length < 8) {
            return sendBtn(
                `Nomor tidak valid. Contoh: *${p}jadibot 628xxxxxxxxxx*`,
                [
                    quick('📱 Petunjuk Pairing', `${p}jadibotcode`),
                    quick('📷 QR Code', `${p}jadibotqr`)
                ]
            )
        }
        if (clones.has(number)) {
            return sendBtn(
                `Nomor ${formatPhone(number)} sudah punya sesi jadibot aktif.`,
                [quick('🛑 Stop & Ulangi', `${p}stopjadibot ${number}`), quick('📋 List Jadibot', `${p}listjadibot`)]
            )
        }

        await reply(`Menyiapkan jadibot untuk ${formatPhone(number)}, tunggu kode pairingnya ya...`)

        try {
            await startJadibot(number, { sock, jid, prefix: p }, m.sender, 'code')
        } catch (e) {
            await reply(`Gagal memulai jadibot: ${e.message}`)
        }
        return
    }

    if (command === 'stopjadibot') {
        const input = String(text || '').trim()

        // tanpa argumen: tampilkan pilihan sesi lewat tombol
        if (!input) {
            const list = visibleSessions()
            if (!list.length) return reply(isOwner ? 'Tidak ada sesi jadibot yang aktif saat ini.' : 'Kamu belum punya sesi jadibot yang aktif.')
            return sendBtn('Pilih sesi jadibot yang mau dihentikan:', [stopPicker(list)])
        }

        // sesi QR yang belum di-scan dikenali lewat kunci "qr-xxxx"
        const id = /^qr-/i.test(input) ? input.toLowerCase() : normalize(input)

        if (!clones.has(id)) return reply('Tidak ada sesi jadibot aktif untuk nomor itu.')

        // user premium hanya boleh menghentikan sesi yang dia buat sendiri; owner boleh semua
        const session = listJadibot().find((s) => s.number === id)
        if (!isOwner && session?.requester !== m.sender) return reply('Itu bukan sesi jadibot milikmu.')

        // balas dulu, baru matikan socket: kalau command ini diterima lewat socket jadibot
        // yang sedang dihentikan, balasan tidak akan terkirim kalau socketnya sudah ditutup
        await sendBtn(
            `Jadibot ${session?.pending ? id : formatPhone(id)} dihentikan dan sesinya dihapus.`,
            [quick('📱 Pairing Code', `${p}jadibotcode`), quick('📷 QR Code', `${p}jadibotqr`)]
        ).catch(() => null)
        try {
            await stopJadibot(id)
        } catch (e) {
            console.error(e)
        }
        return
    }

    if (command === 'listjadibot') {
        // user premium hanya melihat sesi miliknya; owner melihat semua
        const list = visibleSessions()
        if (!list.length) {
            return sendBtn(
                isOwner ? 'Tidak ada sesi jadibot yang aktif saat ini.' : 'Kamu belum punya sesi jadibot yang aktif.',
                [quick('📱 Pairing Code', `${p}jadibotcode`), quick('📷 QR Code', `${p}jadibotqr`)]
            )
        }

        const lines = list.map(({ number, startedAt, mode, pending }, i) => {
            const via = mode === 'qr' ? 'QR' : 'pairing code'
            const who = pending ? `${number} (menunggu scan)` : formatPhone(number)
            return `${i + 1}. ${who} — ${via}, aktif ${runtime((Date.now() - startedAt) / 1000)}`
        })

        return sendBtn(
            `*Jadibot aktif (${list.length}):*\n\n${lines.join('\n')}`,
            [
                stopPicker(list),
                quick('📱 Tambah Pairing', `${p}jadibotcode`),
                quick('📷 Tambah QR', `${p}jadibotqr`)
            ]
        )
    }
}

handler.command = ['jadibot']
handler.subs = ['jadibotcode', 'jadibotqr', 'listjadibot', 'stopjadibot']
handler.tags = ['premium']
handler.premium = true
handler.owner = true

export default handler
