import axios from 'axios'

const TEMP_API = 'https://tempmail-donz.vercel.app/api'
const TEMP_WEB = 'https://tempmail-donz.vercel.app'
const API_NOXX = 'https://am.noxxyrorr.biz.id/api'

const MAX_COUNT = 3            // batas akun per perintah (ubah bila perlu)
const POLL_ATTEMPTS = 20       // berapa kali cek inbox menunggu magic link
const POLL_INTERVAL = 3000     // jeda tiap cek inbox (ms)
const GAP_BETWEEN = 2000       // jeda antar akun (ms)

const HEADERS = {
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Content-Type': 'application/json',
    Accept: 'application/json, text/plain, */*',
}

const http = axios.create({ headers: HEADERS, timeout: 30000 })
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const busy = new Set()

async function react(sock, m, emoji) {
    try { await sock.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch {}
}

// ================== LANGKAH-LANGKAH ==================

async function createMail() {
    const { data } = await http.post(`${TEMP_API}/create`, {})
    if (!data?.success || !data?.email) throw new Error('Gagal membuat email sementara')
    return { email: data.email, token: data.token }
}

async function sendLink(email) {
    const { data } = await http.post(`${API_NOXX}/send-link`, { email })
    if (!data?.success) throw new Error(data?.message || 'Gagal mengirim magic link')
    return data
}

async function waitForMagicLink(email) {
    const encoded = encodeURIComponent(email)

    for (let i = 1; i <= POLL_ATTEMPTS; i++) {
        try {
            const { data } = await http.get(`${TEMP_API}/inbox/${encoded}`)

            if (Array.isArray(data) && data.length > 0) {
                for (const mail of data) {
                    const html = mail.body_html || ''
                    const match = html.match(
                        /href=['"]([^'"]+alight-creative\.firebaseapp\.com[^'"]+)['"]/i
                    )
                    if (match) {
                        return { magicLink: match[1], subject: mail.subject, from: mail.from }
                    }
                }
            }
        } catch {
            // coba lagi
        }

        await sleep(POLL_INTERVAL)
    }

    throw new Error('Magic link tidak ditemukan (timeout)')
}

async function verifyLink(email, magicLink) {
    const { data } = await http.post(`${API_NOXX}/verify-link`, { email, magicLink })
    if (!data?.success || !data?.ok) throw new Error(data?.message || 'Verifikasi gagal')
    return data
}

async function claimOne() {
    const result = { status: false }

    try {
        const { email } = await createMail()
        result.email = email
        result.inbox = `${TEMP_WEB}/${email}`

        await sendLink(email)
        const mail = await waitForMagicLink(email)
        const v = await verifyLink(email, mail.magicLink)

        result.status = true
        result.uid = v.data?.uid
        result.orderId = v.data?.orderId
        result.tier = v.data?.tier
        result.validUntil = v.data?.validUntil
    } catch (err) {
        result.error = err.response?.data?.message || err.message
    }

    return result
}

// ================== HANDLER ==================

let handler = async (m, { sock, text, prefix, command, reply }) => {
    const raw = String(text || '').trim()
    const count = raw ? parseInt(raw, 10) : 1

    if (!Number.isInteger(count) || count < 1) {
        return reply(
            `*AMBULK - Klaim Alight Motion*\n` +
            `─────────────────────\n` +
            `${prefix}${command} [jumlah]\n\n` +
            `Contoh:\n${prefix}${command}\n${prefix}${command} 2\n\n` +
            `_Maksimal ${MAX_COUNT} akun per perintah. Tiap akun bisa memakan waktu sampai ±1 menit._`
        )
    }

    if (count > MAX_COUNT) return reply(`Maksimal ${MAX_COUNT} akun per perintah.`)
    if (busy.has(m.sender)) return reply('⏳ Proses sebelumnya masih berjalan, tunggu selesai dulu.')

    busy.add(m.sender)
    await react(sock, m, '🕕')

    try {
        await reply(`⏳ Memproses *${count}* akun, mohon tunggu...`)

        const results = []
        for (let i = 1; i <= count; i++) {
            results.push(await claimOne())
            if (i < count) await sleep(GAP_BETWEEN)
        }

        const success = results.filter((r) => r.status).length
        const failed = results.length - success

        const lines = [
            `*AMBULK - HASIL*`,
            `─────────────────────`,
            `Total   : ${results.length}`,
            `Berhasil: ${success}`,
            `Gagal   : ${failed}`,
        ]

        results.forEach((r, i) => {
            lines.push('', `*#${i + 1}* ${r.status ? '✅' : '❌'}`)
            if (r.email) lines.push(`Email   : ${r.email}`)
            if (r.status) {
                if (r.tier) lines.push(`Tier    : ${r.tier}`)
                if (r.validUntil) lines.push(`Sampai  : ${r.validUntil}`)
                if (r.uid) lines.push(`UID     : ${r.uid}`)
                if (r.orderId) lines.push(`Order ID: ${r.orderId}`)
            } else {
                lines.push(`Error   : ${r.error || 'tidak diketahui'}`)
            }
            if (r.inbox) lines.push(`Inbox   : ${r.inbox}`)
        })

        await reply(lines.join('\n'))
        await react(sock, m, success ? '✅' : '❌')
    } catch (e) {
        console.error('[AMBULK]', e)
        await react(sock, m, '❌')
        await reply(`❌ Gagal: ${e.message}`)
    } finally {
        busy.delete(m.sender)
    }
}

handler.command = ['ambulk']
handler.help = ['ambulk [jumlah]']
handler.tags = ['premium']
handler.limit = true

export default handler
