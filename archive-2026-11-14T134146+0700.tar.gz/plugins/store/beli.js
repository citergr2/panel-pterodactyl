/**
 * Kaguya Multi Device — Store
 * .beli — beli kode
 * Satu file = satu command. Helper bersama: lib/store/shop.js
 */

import QRCode from 'qrcode'
import { saveDB } from '../../lib/core/system.js'
import { storeReply, sendBtn, quick, copyBtn, gwReady, createStoreOrder } from '../../lib/store/merchant.js'
import { toPN } from '../../lib/engine/plugins.js'
import { autoSeed } from '../../lib/store/catalog.js'
import { ORDER_TTL_MIN, UNIQUE_MAX, QRIS, qrisReady, toDynamic, getDB, rp, ACTIVE, STATUS, expireOrders, available } from '../../lib/store/shop.js'

// ===== .beli kode =====
let handler = async (m, { sock, text, command, prefix, isOwner, reply: baseReply }) => {
    const reply = storeReply(sock, m, baseReply)
    const p = prefix || '.'
    const body = (text || '').trim()
    // id tombol = command lengkap (tiap command punya file sendiri)
    const S = (sub, args = '') => `${p}${sub}${args ? ` ${args}` : ''}`
    const btn = (text, buttons, o = {}) => sendBtn(sock, m.chat, { text, buttons, ...o }, m)
    const katalogBtn = quick('🛍 Katalog', S('produk'))
    const riwayatBtn = quick('🧾 Riwayat', S('riwayat'))
    const cut = (str, n) => (String(str).length > n ? `${String(str).slice(0, n - 1)}…` : String(str))
    autoSeed() // isi katalog contoh + terapkan global.storeProducts (config.js)
    const d = getDB()
    expireOrders()
    if (!gwReady() && !qrisReady()) {
        return reply(isOwner
            ? 'QRIS belum diisi. Isi global.merchantGw (QRIS GoPay otomatis) atau global.qrisStatic di config.js.'
            : 'Pembelian belum tersedia saat ini.')
    }
    const pr = d.products[body.toLowerCase()]
    if (!body) return reply(`Format: ${p}beli <kode>\nLihat daftar: ${p}produk`)
    if (!pr) return reply(`Produk "${body}" tidak ditemukan. Ketik ${p}produk untuk melihat daftar.`)
    if (available(pr) <= 0) return btn(`Maaf, *${pr.name}* sedang habis.`, [katalogBtn])

    const buyer = await toPN(sock, m.sender)
    const running = Object.values(d.orders).find(o => o.buyer === buyer && ACTIVE.has(o.status))
    if (running) {
        return btn(
            `Kamu masih punya order *${running.id}* (${STATUS[running.status]}).\n${running.status === 'pending' ? 'Bayar dulu atau batalkan ordernya.' : 'Tunggu konfirmasi owner ya.'}`,
            running.status === 'pending' ? [quick('🚫 Batalkan Order', S('batalorder')), quick('📸 Cara Kirim Bukti', S('bukti'))] : [riwayatBtn, katalogBtn]
        )
    }

    // QRIS GoPay otomatis (merchant GoBiz): pembayaran dicek bot, produk dikirim sendiri begitu lunas.
    // Kalau global.merchantGw belum diisi, alur lama di bawah (QRIS statis + bukti manual) tetap dipakai.
    if (gwReady()) return createStoreOrder({ sock, m, pr, buyer, p, isOwner })

    const usedTotals = new Set(Object.values(d.orders).filter(o => o.status === 'pending').map(o => o.total))
    const free = []
    for (let u = 1; u <= UNIQUE_MAX; u++) if (!usedTotals.has(pr.price + u)) free.push(u)
    if (!free.length) return btn('Sedang ramai, coba lagi beberapa menit lagi ya.', [quick('🔁 Coba Lagi', S('beli', pr.code))])
    const unique = free[Math.floor(Math.random() * free.length)]
    const total = pr.price + unique

    d.seq += 1
    const id = `INV-${String(d.seq).padStart(4, '0')}`
    d.orders[id] = {
        id, code: pr.code, name: pr.name, price: pr.price, unique, total,
        buyer, chat: m.chat, status: 'pending', createdAt: Date.now()
    }
    saveDB(global.db)

    const image = await QRCode.toBuffer(toDynamic(QRIS, total), { width: 600, margin: 3, errorCorrectionLevel: 'M' })
    return btn(null, [
        quick('📸 Cara Kirim Bukti', S('bukti')),
        copyBtn('📋 Salin Nominal', total),
        quick('🚫 Batalkan Order', S('batalorder'))
    ], {
        image,
        text:
            `╭─▣「 *INVOICE ${id}* 」▣─╮\n` +
            `┃ 🛍️ Produk     : ${pr.name}\n` +
            `┃ 💰 Harga      : ${rp(pr.price)}\n` +
            `┃ 🔢 Kode unik  : ${unique}\n` +
            `┃ 💳 *Total bayar : ${rp(total)}*\n` +
            `┃ ⏳ Berlaku    : ${ORDER_TTL_MIN} menit\n` +
            `╰─────────────➤\n\n` +
            `1. Scan QR di atas lewat e-wallet / m-banking (QRIS).\n` +
            `2. Bayar *tepat ${rp(total)}* (termasuk kode unik).\n` +
            `3. Kirim foto bukti bayar dengan caption *${p}bukti* (atau balas fotonya dengan *${p}bukti*).`
    })
}

handler.command = ['beli']
handler.tags = ['store']
handler.help = ['beli']

export default handler
